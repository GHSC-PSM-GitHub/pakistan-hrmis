<?php

require_once 'classes/category.php';
require_once 'classes/datetime.php';

$category = new category();
$category_id = $_POST['id'];
$file = $category->find_by_id($category_id);
$data = $file->fetch_array();

?>
<!-- Row -->
<div class="row-fluid">

    <!-- Column -->
    <div class="span12">

        <!-- Group -->                     
        <div class="control-group">
            <label class="control-label" for="category_value">Category</label>
            <div class="controls"><input class="span12" id="category_value" name="category_value" type="text" value="<?php echo $data['category_value']; ?>" /></div>
        </div>                         
    </div>
    <!-- // Column END -->



</div>

<input type="hidden" name="categoryid" value="<?php echo $category_id; ?>"/>