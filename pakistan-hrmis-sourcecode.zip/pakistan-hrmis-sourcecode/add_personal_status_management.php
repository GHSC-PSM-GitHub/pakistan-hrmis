<?php

session_start();
require_once 'classes/personal_status.php';

require_once 'classes/datetime.php';

$speciality = new personal_status();
//$file = $speciality->save();

if(isset($_REQUEST['fileid']) && !empty($_REQUEST['fileid'])){
    $speciality->pk_id = $_REQUEST['fileid'];
}
$speciality->personal_status = $_POST['personal_status'];
$speciality->is_active = 1;

$file = $speciality->save();

if ($file) {
    header("location: personal_status_record.php");
} else {
    header("location: personal_status_record.php");
}