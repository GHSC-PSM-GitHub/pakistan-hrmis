<?php

session_start();
require_once 'classes/role_actions.php';
require_once 'classes/datetime.php';

$cadre = new role_actions();

$cadre->role_id = $_POST['id'];
$cadre->action = $_POST['action'];
$cadre->allow = $_POST['type'];

$file = $cadre->update2();