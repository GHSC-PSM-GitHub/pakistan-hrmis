<?php

session_start();
require_once 'classes/cadre.php';
require_once 'classes/datetime.php';

$cadre = new cadre();

if (isset($_REQUEST['cadreid']) && !empty($_REQUEST['cadreid'])) {
    $cadre->pk_id = $_REQUEST['cadreid'];
}

$cadre->cadre_value = $_POST['cadre_value'];

$cadre->is_active = 1;


$file = $cadre->save();

if ($file) {
    header("location: cadre.php");
} else {
    header("location: cadre.php");
}