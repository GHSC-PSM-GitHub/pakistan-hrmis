<?php

session_start();
require_once 'classes/transfer_status.php';

require_once 'classes/datetime.php';

$speciality = new transfer_status();
//$file = $speciality->save();

if(isset($_REQUEST['fileid']) && !empty($_REQUEST['fileid'])){
    $speciality->pk_id = $_REQUEST['fileid'];
}
$speciality->transfer_status = $_POST['transfer_status'];
$speciality->is_active = 1;

$file = $speciality->save();

if ($file) {
    header("location: transfer_status_record.php");
} else {
    header("location: transfer_status_record.php");
}