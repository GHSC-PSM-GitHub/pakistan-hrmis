<?php

session_start();
require_once 'classes/penalties.php';
require_once 'classes/datetime.php';

$post = new penalties();



$uploading = false;

if (isset($_FILES['apointment_letter'])) {
    $uploading = true;
    $_SESSION['msg'] = '';
    $file_name = $_FILES['apointment_letter']['name'];
    $file_size = $_FILES['apointment_letter']['size'];
    $file_tmp = $_FILES['apointment_letter']['tmp_name'];
    $file_type = $_FILES['apointment_letter']['type'];
    if(!empty($_FILES['apointment_letter']['name'])){
        $file_ext = strtolower((explode('.', $_FILES['apointment_letter']['name'])[1]));
    }    

    $extensions = array("jpeg", "jpg", "png", "pdf", "docx", "doc");

//    if (in_array($file_ext, $extensions) === false) {
//        $_SESSION['msg'] = "Error! extension not allowed, please choose an image, pdf or doc file";
//    }

    if ($file_size > 5097152) {
        $_SESSION['msg'] = 'Error! File size must be exactly 5 MB';
    }

    if (empty($_SESSION['msg']) == true) {
        move_uploaded_file($file_tmp, "upload/" . $file_name);
    }
}

if(isset($_REQUEST['fileid']) && !empty($_REQUEST['fileid'])){
    $post->pk_id = $_REQUEST['fileid'];
}

$post->employee_id = $_POST['employee'];
$post->penalty_type = $_POST['penalty_type'];
$post->penalty_by = $_POST['penalty_by'];
$post->penalty_date = $dt->dbformat($_POST['date']);
$post->from_date = $dt->dbformat($_POST['from_date']);
$post->to_date = $dt->dbformat($_POST['to_date']);
$post->remarks = $_POST['remarks'];
$post->is_active = 1;
$post->file = $file_name;
$file = $post->save();

if ($file) {
    header("location: penalties_mgmt.php");
} else {
    header("location: penalties_mgmt.php");
}