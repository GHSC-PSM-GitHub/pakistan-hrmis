<?php

require_once 'classes/database.php';
require_once 'classes/personal.php';

$empnm = $_POST['emp'];
$personal = new personal();
$query = $personal->find_by_empnumber($empnm);
if (!empty($query)) {
    echo 'true';
} else {
    echo 'false';
}
?>