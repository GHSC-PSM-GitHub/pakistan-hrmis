<?php
require_once 'classes/reward.php';
require_once 'classes/datetime.php';

$reward = new reward();
$file_id = $_POST['id'];
$file = $reward->find_by_id($file_id);
$data = $file->fetch_array();

?>
<!-- Row -->
<div class="row-fluid">

    <!-- Column -->
    <div class="span12">

        <!-- Group -->
        <!-- Group -->
            <div class="control-group">
                <label class="control-label" for="r_date">Reward Date</label>
                <div class="controls"><input class="span12" id="r_date" name="r_date" type="text" value="<?php echo $dt->dateformat($data['reward_date']); ?>" required=""/></div>
            </div>
            <div class="control-group">
                <label class="control-label" for="employee_id">Employee Name</label>
                <div class="controls">
                    <select class="span12" id="employee_id" name="employee_id">
                        <option value="">Select</option>
                        <?php
                        $location = new reward();
                        $result = $location->rewarddropdown();
                        while ($row = $result->fetch_assoc()) {
                            ?>
                            <option value="<?php echo $row['pk_id']; ?>"  <?php if ($data['pk_id'] == $row['pk_id']) { ?>selected=""<?php } ?>><?php echo $row['name']; ?></option>
                            <?php
                        }
                        ?>
                    </select></div>
            </div>  
        <!--                    <div class="control-group">
                <label class="control-label" for="employee_name">Employee Name</label>
                <div class="controls"><input class="span12" id="employee_name" name="employee_name" type="text" required="" /></div>
            </div>  -->
            <div class="control-group">
                <label class="control-label" for="r_aprov_by">Reward Approved By</label>
                <div class="controls"><input class="span12" id="r_aprov_by" name="r_aprov_by" type="text" value="<?php echo $data['reward_approved_by']; ?>" required="" /></div>
            </div>
            <div class="control-group">
                <label class="control-label" for="desc">Remarks</label>
                <div class="controls"><input class="span12" id="desc" name="desc" type="text" value="<?php echo $data['reward_desc']; ?>" required="" /></div>
            </div>                        
            <div class="control-group">
                <label class="control-label" for="apointment_letter">Attach file</label>
                <div class="controls"><input type="file" id="apointment_letter" name="apointment_letter" /></div>
            </div>
    </div>
    <!-- // Column END -->



</div>

<input type="hidden" name="fileid" value="<?php echo $file_id; ?>"/>