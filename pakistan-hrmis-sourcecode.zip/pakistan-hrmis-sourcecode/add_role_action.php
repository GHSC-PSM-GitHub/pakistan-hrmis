<?php

session_start();
require_once 'classes/role_action.php';
require_once 'classes/datetime.php';

$role_action = new role_action();

if (isset($_REQUEST['roleid']) && !empty($_REQUEST['roleid'])) {
    $role_action->pk_id = $_REQUEST['roleid'];
}

$role_action->role_id = $_POST['role_id'];

$role_action->allow = 'TRUE';


$file = $role_action->save();

if ($file) {
    header("location: role_action.php");
} else {
    header("location: role_action.php");
}