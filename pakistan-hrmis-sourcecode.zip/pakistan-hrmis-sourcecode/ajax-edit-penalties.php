<?php
require_once 'classes/penalties.php';
require_once 'classes/personal.php';
require_once 'classes/datetime.php';

$personal = new personal();
$post = new penalties();
$file_id = $_POST['id'];
$file = $post->find_by_id($file_id);
$data = $file->fetch_array();
?>
<!-- Row -->
<div class="row-fluid">

    <!-- Column -->
    <div class="span12">

        <!-- Group -->
        <div class="control-group">
            <label class="control-label" for="specility">Employee Name</label>
            <div class="controls">
                <?php
                $data1 = $personal->get_combo();
                echo create_combo("employee", $data1, $data['employee_id']); ?>
            </div>
        </div>
        <div class="control-group">
            <label class="control-label" for="specility">Kind of Penalty</label>
            <div class="controls">
                <select class="span12" id="penalty_type" name="penalty_type">
                    <optgroup label="Minor Penalties">
                        <option value="Censure">Censure</option>
                        <option value="Withholding">Withholding</option>
                        <option value="Recovery">Recovery</option>
                    </optgroup>
                    <optgroup label="Major Penalties">
                        <option value="Reduction">Reduction</option>
                        <option value="compulsory retirement">compulsory retirement</option>
                        <option value="removal from service">removal from service</option>
                        <option value="dismissal from service">dismissal from service</option>
                        <option value="Reduction">Reduction</option>
                    </optgroup>
                </select></div>
        </div>
        <div class="control-group">
            <label class="control-label" for="penalty_by">Penalty By</label>
            <div class="controls"><input class="span12" id="penalty_by" name="penalty_by" type="text" required="" value="<?php echo $data['penalty_by']; ?>" /></div>
        </div>
        <div class="control-group">
            <label class="control-label" for="date">Effective Date</label>
            <div class="controls"><input class="span12" id="date" name="date" type="text" required="" value="<?php echo $dt->dateformat($data['penalty_date']); ?>" /></div>
        </div>
        <div class="control-group">
            <label class="control-label" for="from_date">From Date</label>
            <div class="controls"><input class="span12" id="from_date" name="from_date" type="text" required="" value="<?php echo $dt->dateformat($data['from_date']); ?>" /></div>
        </div>
        <div class="control-group">
            <label class="control-label" for="to_date">To Date</label>
            <div class="controls"><input class="span12" id="to_date" name="to_date" type="text" required="" value="<?php echo $dt->dateformat($data['to_date']); ?>" /></div>
        </div>
        <div class="control-group">
            <label class="control-label" for="remarks">Remarks</label>
            <div class="controls"><input class="span12" id="remarks" name="remarks" type="text" required="" value="<?php echo $data['remarks']; ?>" /></div>
        </div>
        <div class="control-group">
            <label class="control-label" for="apointment_letter">Attach file</label>
            <div class="controls"><input type="file" id="apointment_letter" name="apointment_letter" /></div>
        </div>

    </div>
    <!-- // Column END -->



</div>

<input type="hidden" name="fileid" value="<?php echo $file_id; ?>" />