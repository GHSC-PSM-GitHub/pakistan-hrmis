<?php


session_start();
require_once 'classes/personal.php';
require_once 'classes/datetime.php';

$personal = new personal();
if(isset($_REQUEST['personalid']) && !empty($_REQUEST['personalid'])){
    $personal->pk_id = $_REQUEST['personalid'];
}
$personal->name = $_POST['name'];
$personal->father_name = $_POST['father_name'];
$personal->gender = $_POST['gender'];
$personal->cnic = $_POST['cnic'];
$personal->district_of_domicile = $_POST['district_of_domicile'];
$personal->date_of_birth = $dt->dbformat($_POST['date_of_birth']);
//$personal->date_of_appointment = $dt->dbformat($_POST['date_of_appointment']);
$personal->contact_no = $_POST['contact_no'];
$personal->email = $_POST['email'];
$personal->postal_address = $_POST['postal_address'];
$personal->pmdc_registration = $_POST['pmdc_registration'];
$personal->marital_status = $_POST['marital_status'];
$personal->health_professional = 'Yes';
$personal->status_two = $_POST['status_two'];
$personal->residential_address = $_POST['residential_address'];
$personal->current_address = $_POST['current_address'];
$personal->residential_city = $_POST['residential_city'];
$personal->current_city = $_POST['current_city'];
$personal->employee_number = $_POST['employee_number'];

$result1 = $personal->sen_joining_same($_POST['bps'],$_POST['cadre_value'],$_POST['joining_date']);
while ($row = $result1->fetch_array()) {
    $joining_count = $row['same_joining_count'];
}
//if($joining_count > 1)
//{
//    $result1 = $personal->seniority_age($_POST['bps'],$_POST['cadre_value'],$_POST['joining_date'],$dt->dbformat($_POST['date_of_birth']));
//    while ($row = $result1->fetch_array()) {
//        $age_count = $row['age_count'];
//    }
//    if($age_count)
//    {
//        $personal->seniority_number = $age_count+1;
//    }
//    else
//    {
//        $personal->seniority_number = '1';
//    }
//}
//else{
//    $result = $personal->seniority_no($_POST['bps'],$_POST['cadre_value'],$_POST['joining_date']);
//    while ($row = $result->fetch_array()) {
//        $count = $row['seniority_count'];
//    }
//    if($count>1)
//    {
//        $personal->seniority_number = $count+1;
//    }
//    else
//    {
//        $personal->seniority_number = '1';
//    }
//}
$personal->seniority_number = $_POST['seniority_number'];
$personal->seniority_number = $_POST['seniority_number'];
$personal->cadre_value = $_POST['cadre_value'];
$personal->ddo_number = $_POST['ddo_number'];
$personal->ddo_description = $_POST['ddo_description'];
$personal->husband_name = $_POST['husband_name'];
$personal->created_by = $_SESSION['userid'];
$personal->mod_app = $_POST['mod_app'];
$personal->quota = $_POST['quota'];
$personal->office = $_POST['sel_office'];
$personal->pass_no = (!empty($_POST['pass_no']) ? $_POST['pass_no'] : 0);
$personal->bps = $_POST['bps'];
$personal->actual_desg = $_POST['actual_desg'];

$personal->sancpost_id = $_POST['sancpost'];

//$personal->additional_charge = $_POST['additional_charge'];
$personal->seniority_number = $_POST['seniority_number'];
$str_dashes = $_POST['joining_date'];
$str_d =  substr_count($str_dashes, '-');
if($str_d == '2')
{
    $personal->joining_date = $_POST['joining_date'];
}
else{
    $personal->joining_date = $dt->dbformat($_POST['joining_date']);
}
$personal->category_value = $_POST['category_value'];
$personal->status = ($_POST['status_two'] === 'Retired')?'0':'1';;
$personal->nationality = json_encode(array($_POST['nationality']));
$id = $personal->save();

echo $id;