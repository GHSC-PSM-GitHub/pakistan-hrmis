<!DOCTYPE html>
<!--[if lt IE 7]> <html class="ie lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>    <html class="ie lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>    <html class="ie lt-ie9"> <![endif]-->
<!--[if gt IE 8]> <html class="ie gt-ie8"> <![endif]-->
<!--[if !IE]><!--><html><!-- <![endif]-->
    <head>
        <title>HR Khyber Pakhtunkhwa</title>

        <!-- Meta -->
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="apple-mobile-web-app-status-bar-style" content="black">
        <meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />

        <!-- Bootstrap -->
        <link href="common/bootstrap/css/bootstrap.css" rel="stylesheet" />
        <link href="common/bootstrap/css/responsive.css" rel="stylesheet" />

        <!-- Glyphicons Font Icons -->
        <link href="common/theme/css/glyphicons.css" rel="stylesheet" />

        <!-- Uniform Pretty Checkboxes -->
        <link href="common/theme/scripts/plugins/forms/pixelmatrix-uniform/css/uniform.default.css" rel="stylesheet" />

        <!-- PrettyPhoto -->
        <link href="common/theme/scripts/plugins/gallery/prettyphoto/css/prettyPhoto.css" rel="stylesheet" />

        <!-- Main Theme Stylesheet :: CSS -->
        <link href="common/theme/css/style-light.css?1369414386" rel="stylesheet" />
        <link href="http://localhost/hrkp/common/theme/css/green.css" rel="stylesheet" />

        <!-- LESS.js Library -->
        <script src="common/theme/scripts/plugins/system/less.min.js"></script>
        <style>
        #image  {
                background-image: url("common/theme/images/loginbg.jpg");
                height: 100vh;
                width: 100%;
                margin: 0;
                background-size:cover;
                position: relative;
                padding-top: 40px;
        }
        </style>
    </head>
    <body class="login" id="image">

        <!-- Wrapper -->
       <div id="login">

            <!-- Box -->
            <div class="form-signin" style="margin-top: 30px;">
                <h3>Change Password</h3>

                <!-- Row -->
                <div class="row-fluid row-merge">

                    <!-- Column -->
                    <div class="span12">
                        <div class="inner">
                        <!--<h4 class="text-muted font-18 mb-3 text-center">CHANGE PASSWORD</h4>-->
<!--                        <div class="alert alert-info" role="alert">
                            Enter your <b>Email</b> and <b>Password</b> will be sent to you!
                        </div>

                        <h3 align="center">CHANGE PASSWORD</h3>-->
                        <div><?php if(isset($message)) { echo $message; } ?></div>
                        <form method="post" class="form-horizontal m-t-30" action="password_changed.php" align="center">
                         <div class="form-row">
                            <label for="exampleFormControlTextarea1">Current Password: <span style="color:red;">*</span></label>
                         <input type="password" class="form-control" name="currentPassword"><span id="currentPassword" class="required"></span>
                         </div>
                         <div class="form-row">
                        <label for="exampleFormControlTextarea1">New Password: <span style="color:red;">*</span></label>
                        <input type="password" class="form-control" name="newPassword"><span id="newPassword" class="required"></span>
                        </div>
                        <div class="form-row">
                            <label for="exampleFormControlTextarea1">Confirm Password: <span style="color:red;">*</span></label>
                         <input type="password" class="form-control" name="confirmPassword"><span id="confirmPassword" class="required"></span>
                        </div>                            
                            <div class="form-group row m-t-20">
                                <div class="col-12 text-right">
                                    <button class="btn btn-primary w-md waves-effect waves-light" type="submit">Submit</button>
                                    <!--<p class="text-muted">Remember It ? <a href="pages-login.html"> Sign In Here </a> </p>-->
                                </div>
                            </div>
                            <div class="m-t-40 text-center">
                                <p class="text-muted">Dont't want to change ? <a href="index.php" style="color: #23A9C6;"> <b>Click Here</b> </a> </p>
                                <!--<p class="text-muted">© 2018 Agroxa. Crafted with <i class="mdi mdi-heart text-danger"></i> by Themesbrand</p>-->
                            </div>
                        </form>
                    </div>

                </div>
            </div>

<!--            <div class="m-t-40 text-center">
                <p class="text-muted">Remember It ? <a href="pages-login.html" class="text-white"> Sign In Here </a> </p>
                <p class="text-muted">© 2018 Agroxa. Crafted with <i class="mdi mdi-heart text-danger"></i> by Themesbrand</p>
            </div>-->

        </div>

       <!-- // Wrapper END -->	

        <!-- JQuery -->
        <script src="common/theme/scripts/plugins/system/jquery.min.js"></script>

        <!-- JQueryUI -->
        <script src="common/theme/scripts/plugins/system/jquery-ui/js/jquery-ui-1.9.2.custom.min.js"></script>

        <!-- JQueryUI Touch Punch -->
        <!-- small hack that enables the use of touch events on sites using the jQuery UI user interface library -->
        <script src="common/theme/scripts/plugins/system/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

        <!-- Modernizr -->
        <script src="common/theme/scripts/plugins/system/modernizr.js"></script>

        <!-- Bootstrap -->
        <script src="common/bootstrap/js/bootstrap.min.js"></script>

        <!-- SlimScroll Plugin -->
        <script src="common/theme/scripts/plugins/other/jquery-slimScroll/jquery.slimscroll.min.js"></script>

        <!-- Common Demo Script -->
        <script src="common/theme/scripts/demo/common.js?1369414386"></script>

        <!-- Holder Plugin -->
        <script src="common/theme/scripts/plugins/other/holder/holder.js"></script>

        <!-- Uniform Forms Plugin -->
        <script src="common/theme/scripts/plugins/forms/pixelmatrix-uniform/jquery.uniform.min.js"></script>

        <!-- PrettyPhoto -->
        <script src="common/theme/scripts/plugins/gallery/prettyphoto/js/jquery.prettyPhoto.js"></script>

        <!-- Global -->
        <script>
            var basePath = 'common/';
        </script>



    </body>
</html>