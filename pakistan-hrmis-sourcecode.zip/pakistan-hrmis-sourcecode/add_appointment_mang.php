<?php

session_start();
require_once 'classes/mode_of_appointment.php';

require_once 'classes/datetime.php';

$appointment = new appointment();
//$file = $speciality->save();

if(isset($_REQUEST['fileid']) && !empty($_REQUEST['fileid'])){
    $appointment->pk_id = $_REQUEST['fileid'];
}
$appointment->appointment_type = $_POST['appointment_type'];
$appointment->is_active = 1;

$file = $appointment->save();

if ($file) {
    header("location: mode_of_appointment.php");
} else {
    header("location: mode_of_appointment.php");
}