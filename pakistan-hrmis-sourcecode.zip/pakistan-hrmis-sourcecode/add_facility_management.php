<?php

session_start();
require_once 'classes/facility_type.php';

require_once 'classes/datetime.php';

$speciality = new facility();
//$file = $speciality->save();

if(isset($_REQUEST['fileid']) && !empty($_REQUEST['fileid'])){
    $speciality->pk_id = $_REQUEST['fileid'];
}
$speciality->facility_type = $_POST['facility_type'];
$speciality->is_active = 1;

$file = $speciality->save();

if ($file) {
    header("location: facility_type_record.php");
} else {
    header("location: facility_type_record.php");
}