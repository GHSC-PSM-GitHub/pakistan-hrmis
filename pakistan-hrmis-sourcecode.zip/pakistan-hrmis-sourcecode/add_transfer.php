<?php
    session_start();
    require_once 'classes/transfer_request_form.php';
    require_once 'classes/datetime.php';
    require_once 'classes/config.php';
    
    $date=date_create($_REQUEST['proposed_date']);
    $proposed_date = date_format($date,"Y-m-d H:i:s");
    
     $date1 = date_create($_REQUEST['notification_date']);
    $notification_date = date_format($date1,"Y-m-d H:i:s");
    
    $education = new transfer_management();
    
    
$uploading = false;

if (isset($_FILES['apointment_letter'])) {
    $uploading = true;
    $_SESSION['msg'] = '';
    $file_name = $_FILES['apointment_letter']['name'];
    $file_size = $_FILES['apointment_letter']['size'];
    $file_tmp = $_FILES['apointment_letter']['tmp_name'];
    $file_type = $_FILES['apointment_letter']['type'];
    if(!empty($_FILES['apointment_letter']['name'])){
        $file_ext = strtolower((explode('.', $_FILES['apointment_letter']['name'])[1]));
    }    

    $extensions = array("jpeg", "jpg", "png", "pdf", "docx", "doc");

//    if (in_array($file_ext, $extensions) === false) {
//        $_SESSION['msg'] = "Error! extension not allowed, please choose an image, pdf or doc file";
//    }

    if ($file_size > 5097152) {
        $_SESSION['msg'] = 'Error! File size must be exactly 5 MB';
    }

    if (empty($_SESSION['msg']) == true) {
        move_uploaded_file($file_tmp, "upload/" . $file_name);
    }
}

    if (isset($_REQUEST['educationid']) && !empty($_REQUEST['educationid'])) {
        $education->pk_id = $_REQUEST['educationid'];
    }
    
    $education->posting_form_no = $_REQUEST['posting_form_number'];
    $education->transfer_to_district = $_REQUEST['transfer_to_district'];
    if(isset($_REQUEST['transfer_to_office']) &&  $_REQUEST['transfer_to_office']!= '')
    {
        $education->transfer_to_office = $_REQUEST['transfer_to_office'];
    } else {
        $education->transfer_to_office = $_REQUEST['transfer_to_office1'];
    }
    if(isset($_REQUEST['transfer_to_designation']) &&  $_REQUEST['transfer_to_designation']!= '')
    {
        $education->transfer_to_designation = $_REQUEST['transfer_to_designation'];
    }
    if(isset($_REQUEST['current_designation']) &&  $_REQUEST['current_designation']!= '')
    {
        $education->current_designation = $_REQUEST['current_designation'];
    }
    if(isset($_REQUEST['current_district']) &&  $_REQUEST['current_district']!= '')
    {
        $education->current_district = $_REQUEST['current_district'];
    }
    if(isset($_REQUEST['current_office']) &&  $_REQUEST['current_office']!= '')
    {
        $education->current_office = $_REQUEST['current_office'];
//    $education->current_office = $_REQUEST['transfer_to_office'];
    }
    if(isset($_REQUEST['cc_edit_box']) &&  $_REQUEST['cc_edit_box']!= '')
    {
        $education->cc_edit_box = $_REQUEST['cc_edit_box'];
    }
    if(isset($_REQUEST['document_ref_number']) &&  $_REQUEST['document_ref_number']!= '')
    {
        $education->document_ref_number = $_REQUEST['document_ref_number'];
    }
    if(isset($_REQUEST['description']) &&  $_REQUEST['description']!= '')
    {
        $education->description = $_REQUEST['description'];
    }
    if(isset($_REQUEST['personal_id']) &&  $_REQUEST['personal_id']!= '')
    {
        $education->personal_record_id = $_REQUEST['personal_id'];
    }
    if(isset($_REQUEST['Doctor_Name']) &&  $_REQUEST['Doctor_Name']!= '')
    {
        $education->doctor_name = $_REQUEST['Doctor_Name'];
    }
    if(isset($_REQUEST['transfer_status']) &&  $_REQUEST['transfer_status']!= '')
    {
        $education->transfer_status = $_REQUEST['transfer_status'];
    }
    $education->proposed_date = $proposed_date;
    $education->notification_date = $notification_date;
    $education->file = $file_name;
    
    ///////xxxxxxxxxxxxxx   POSTING RECORD START  xxxxxxxxxxxxxxxxxx/////////////////
    
    $myRes = explode(',', $education->transfer_to_office,2 );
    $myRes = ltrim($myRes[1]);
    $wh_name= "SELECT tbl_warehouse.wh_id FROM tbl_warehouse WHERE tbl_warehouse.wh_name = '$myRes' ";
    $run = mysqli_query($conn, $wh_name);
     $wh_id= mysqli_fetch_assoc($run) ;
     $ware_id = $wh_id['wh_id']; 
    
     $desig = explode('(BPS-', $education->transfer_to_designation );
     $bps = substr_replace($desig[1], "", -1);
     $desig_id= "SELECT posts_record.pk_id FROM posts_record WHERE name = '$desig[0]' AND bps = '$bps' ";
     $run2 = mysqli_query($conn, $desig_id);
     $d_id= mysqli_fetch_assoc($run2) ;
     $post_id =  $d_id['pk_id']; 

    $update_posting_record= "UPDATE posting_record SET status = '0', appointment_end_date = '$proposed_date' WHERE personal_record_id = '$education->personal_record_id' AND status = '1'";
    $run3 = mysqli_query($conn, $update_posting_record);
    
    $insert_query = "INSERT INTO `posting_record`(`post_id`,`post_place_id`,`appointment_start_date`, `file`,`personal_record_id`,`transfer_status`,`status`,`pay_scale`,`notification_date`)"
        . " VALUES ('$post_id','$ware_id','$proposed_date','$file_name','$education->personal_record_id','$education->transfer_status','1','$bps','$notification_date')";
//echo $insert_query; exit;
$run = mysqli_query($conn, $insert_query);
    
    ///////xxxxxxxxxxxxxx   POSTING RECORD END  xxxxxxxxxxxxxxxxxx/////////////////

    $check=mysqli_query($conn,"SELECT
                *
        FROM
                transfer_management
        WHERE
                    transfer_management.transfer_to_designation = '".$education->transfer_to_designation."'
            AND transfer_management.transfer_to_office = '".$education->transfer_to_office."'
            AND transfer_management.transfer_to_district = '".$education->transfer_to_district."'");
//    echo $check;
    $checkrows=mysqli_num_rows($check);
        if($checkrows>0) {
            
    // if query results contains rows then featch those rows 
    	while($row = mysqli_fetch_assoc($check))
    	{
                    $employename = $row['doctor_name'];
                }
            ?>
           <script> alert('<?php echo $employename; ?>' + ' is already on this Post');</script>
           <?php $file = $education->save();
        } 
        else
        {
            $file = $education->save();
        }
        
    $result = $education->find_by_personal($_POST['posting_form_number']);
    if ($result) {
    ?>
        <!-- Table -->

        <table class="dynamicTable table table-striped table-bordered table-condensed">
            <thead>
                <tr>
                    <th style="width: 1%;" class="center">No.</th>
                    <th>Doc Name</th>
                    <th>Current District</th>
                    <th>Current Office</th>
                    <th>Current Designation</th>
                    <th>Transfer To District</th>
                    <th>Transfer To Office</th>
                    <th>Transfer To Designation</th>
                    <th>Transfer Status</th>
                    <th>Proposed Joining Date</th>
                    <th>File</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <!-- Table row -->
                <?php
                $count = 1;
                while ($row = $result->fetch_array()) {

                    $class = "gradeX";
                    if ($count % 2 == 0) {
                        $class = "gradeC";
                    }
                    //$attchment = new attachments();
                    //$att_count = $attchment->count_all($row['pk_id']);
                ?>
                    <tr class="<?php echo $class; ?>">
                        <td class="center"><?php echo $count; ?></td>
                        <td class="important"><?php echo $row['Doctor_Name']; ?></td>
                        <td class="important"><?php echo $row['current_district']; ?></td>
                        <td class="important"><?php echo $row['current_office']; ?></td>
                        <td class="important"><?php echo $row['current_designation']; ?></td>
                        <td class="important"><?php echo $row['transfer_to_district']; ?></td>
                        <td class="important"><?php echo $row['transfer_to_office']; ?></td>
                        <td class="important"><?php echo $row['transfer_to_designation']; ?></td>
                        <td class="important"><?php echo $row['transfer_status']; ?></td>
                        <td class="important"><?php echo $row['proposed_date']; ?></td>
                        <td class="important"><a style="cursor: pointer" onclick="window.open('upload/<?php echo $row['file']; ?>', 'File', 'width:800,height=600')"><?php echo $row['file']; ?></a></td>
                        <td>
                            <a id="<?php echo $row['pk_id']; ?>-deleducation" class="btn-action glyphicons bin" title="delete"><i></i></a>
                        </td>
                    </tr>
                <?php
                    $count++;
                }
                ?>
                <!-- // Table row END -->
                <!-- Table row -->

                <!-- // Table row END -->
            </tbody>
        </table>
        <!-- // Table END -->
    <?php
    } else {
        echo "<hr><h5> No records found!</h5>";
    }
    ?>