<?php
require_once 'classes/transfer_status.php';
require_once 'classes/datetime.php';

$speciality = new transfer_status();
$file_id = $_POST['id'];
$file = $speciality->find_by_id($file_id);
$data = $file->fetch_array();

?>
<!-- Row -->
<div class="row-fluid">

    <!-- Column -->
    <div class="span12">

        <!-- Group -->
        <div class="control-group">
            <label class="control-label" for="specility">Transfer Status</label>
            <div class="controls"><input class="span12" id="transfer_status" name="transfer_status" type="text" value="<?php echo $data['transfer_status']; ?>" /></div>
        </div>                        
      
    </div>
    <!-- // Column END -->



</div>

<input type="hidden" name="fileid" value="<?php echo $file_id; ?>"/>