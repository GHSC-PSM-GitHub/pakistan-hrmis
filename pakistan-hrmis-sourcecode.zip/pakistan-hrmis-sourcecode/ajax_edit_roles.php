<?php

require_once 'classes/roles.php';
require_once 'classes/datetime.php';

$role = new role();
$role_id = $_POST['id'];
$file = $role->find_by_id($role_id);
$data = $file->fetch_array();

?>
<!-- Row -->
<div class="row-fluid">

    <!-- Column -->
    <div class="span12">

        <!-- Group -->                     
        <div class="control-group">
            <label class="control-label" for="category_value">Roles</label>
            <div class="controls"><input class="span12" id="role_name" name="role_name" type="text" value="<?php echo $data['role_name']; ?>" /></div>
        </div>                         
    </div>
    <!-- // Column END-->



</div>

<input type="hidden" name="roleid" value="<?php echo $role_id; ?>"/> 