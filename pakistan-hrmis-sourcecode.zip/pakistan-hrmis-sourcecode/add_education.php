<?php
session_start();
require_once 'classes/education.php';
require_once 'classes/datetime.php';

$education = new education();
if (isset($_REQUEST['educationid']) && !empty($_REQUEST['educationid'])) {
    $education->pk_id = $_REQUEST['educationid'];
}

if (isset($_REQUEST['university_id']) && !empty($_REQUEST['university_id'])) {
    $education->university_id = $_POST['university_id'];
}else if (isset($_REQUEST['university_id1']) && !empty($_REQUEST['university_id1'])) {
    $education->university_id = $_POST['university_id1'];
} else if (isset($_REQUEST['university_id2']) && !empty($_REQUEST['university_id2'])) {
    $education->university_id = $_POST['university_id2'];
}

$education->degree_id = $_POST['degree_id'];
//$education->start_date = $dt->dbformat($_POST['start_date']);
//$education->completion_date = $dt->dbformat($_POST['completion_date']);
$education->e_month = $_POST['e_month'];
$education->e_year = $_POST['e_year'];
$education->e_gpa= $_POST['e_gpa'];
$education->obtained_gpa =(!empty($_POST['obtain_gpa']) ? $_POST['obtain_gpa'] : '0');
$education->percentage = $_POST['percentage'];
//$education->cgpa = $_POST['cgpa'];
$education->total_marks = $_POST['total_marks'];
$education->obtained_marks = (!empty($_POST['obtain_marks']) ? $_POST['obtain_marks'] : '0');
//$education->hec_attestation_no = $_POST['hec_attestation_no'];
//$education->attestation_date = $dt->dbformat($_POST['attestation_date']);
$education->personal_record_id = $_POST['personal_id'];
if(isset($_POST['personal_id']) & !empty($_POST['personal_id']))
{
    $file = $education->save();


$result = $education->find_by_personal($_POST['personal_id']);
if ($result) {
    ?>
    <!-- Table -->

    <table class="dynamicTable table table-striped table-bordered table-condensed">
        <thead>
            <tr>
                <th style="width: 1%;" class="center">No.</th>
                <th>School / College / University Name</th>
                <th>Degree Name</th>
                <th>Ending Month</th>
                <th>Ending Year</th>
                <th>GPA</th>
                <th>Obtained GPA</th>
                <th>Percentage</th>
                <!--<th>CGPA</th>-->
                <th>Total Marks</th>
                <th>Obtained Marks</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <!-- Table row -->
            <?php
            $count = 1;
            while ($row = $result->fetch_array()) {

                $class = "gradeX";
                if ($count % 2 == 0) {
                    $class = "gradeC";
                }
                //$attchment = new attachments();
                //$att_count = $attchment->count_all($row['pk_id']);
                ?>
                <tr class="<?php echo $class; ?>">
                    <td class="center"><?php echo $count; ?></td>
                    <td class="important"><?php echo $row['university_name']; ?></td>
                    <td class="important"><?php echo $row['degree_title']; ?></td>
                    <td class="important"><?php echo $row['e_month']; ?></td>
                    <td class="important"><?php echo $row['e_year']; ?></td>
                    <td class="important"><?php echo $row['e_gpa']; ?></td>
                    <td class="important"><?php echo $row['obtained_gpa']; ?></td>
                    <td><?php echo $row['percentage']; ?></td>
                    <!--<td class="important"><?php // echo $row['cgpa']; ?></td>-->
                    <td class="important"><?php echo $row['total_marks']; ?></td>
                    <td class="important"><?php echo $row['obtained_marks']; ?></td>
                    <td class="center" style="width: 200px;">
                        <a href="#editeducation" data-toggle="modal" id="<?php echo $row['pk_id']; ?>-editid" class="btn-action glyphicons pen" title="editeducation"><i></i></a>
                        <a id="<?php echo $row['pk_id']; ?>-deleducation" class="btn-action glyphicons bin" title="delete"><i></i></a>
                    </td>
                </tr>
                <?php
                $count++;
            }
            ?>
            <!-- // Table row END -->
            <!-- Table row -->

            <!-- // Table row END -->
        </tbody>
    </table>
    <!-- // Table END -->
    <?php
} else {
    echo "<hr><h5> No records found!</h5>";
}

}
else
{?>
    <script>alert("Please save employee profile before adding additional information"); </script>
<?php }

?>
<form class="form-horizontal" enctype="multipart/form-data" style="margin-bottom: 0;" id="validateSubmitForm" method="post" autocomplete="off" action="edit_education.php">
    <div class="modal hide fade" id="editeducation">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h3>Edit</h3>
        </div>
        <div class="modal-body" id="editeducationdiv">
            <div class="center"><img src="common/bootstrap/extend/bootstrap-image-gallery/img/loading.gif"/></div>
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-icon btn-primary glyphicons circle_ok"><i></i>Save</button>
        </div>
    </div>
</form>
<script>
        $("a[id$='-editid']").click(function () {
             var value = $(this).attr("id");
              var pers = $("#personal_id").val();
             var id = value.replace("-editid", "");    

             $.ajax({
                 type: "POST",
                 url: "ajax-edit-education-two.php",
                 data: {
                     id: id,
                       personal_id  : pers
                 },
                 dataType: 'html',
                 success: function (data) {
                     $('#editeducationdiv').html(data);
                     $('#submit').removeAttr("disabled");
     //                $("#doa2,#ed2").datepicker({dateFormat: 'dd/mm/yy'});
                 }
             });
         });
//         ('#type').change(function() {
              $("body").on('change','#type',function(e) {
//                alert('saad');
                var type = $(this).val();
                $.ajax({
                    type: "POST",
                    url: "ajax_education_degree_lvl.php",
                    data: {
                        d_level: type
                    },
                    dataType: 'html',
                    success: function(data) {
//                        alert(data);
//                        alert($('#detaildiv').html(data););
                        $('#degree_level').html(data);
//                        $('#submit').removeAttr("disabled");
                    }
                });
                seltype(type);
            });
    
    function seltype(type)
        {
            if (type == 1)
                {
                    $('#university_combo').fadeIn();
                    $('#university_combo1').fadeOut();
                    $('#university_combo1').val();
                    $('#university_combo2').fadeOut();
                    $('#university_combo2').val();
                }
                if (type == 2)
                {
                    $('#university_combo').fadeIn();
                    $('#university_combo1').fadeOut();
                    $('#university_combo1').val();
                    $('#university_combo2').fadeOut();
                    $('#university_combo2').val();
                }
               else if (type == 3)
                {
                    $('#university_combo').fadeIn();
                    $('#university_combo1').fadeOut();
                    $('#university_combo1').val();
                    $('#university_combo2').fadeOut();
                    $('#university_combo2').val();
                    
                }
                else if (type == 4)
                {
                    $('#university_combo').fadeOut();
                    $('#university_combo').val();
                    $('#university_combo1').fadeIn();
                    $('#university_combo2').fadeOut();
                    $('#university_combo2').val();
                }
                else if (type == 5)
                {
                    $('#university_combo').fadeOut();
                    $('#university_combo').val();
                    $('#university_combo1').fadeIn();
                    $('#university_combo2').fadeOut();
                    $('#university_combo2').val();
                }
                else if (type == 6)
                {
                    $('#university_combo').fadeOut();
                    $('#university_combo').val();
                    $('#university_combo1').fadeIn();
                    $('#university_combo2').fadeOut();
                    $('#university_combo2').val();
                }
                else if (type == 7)
                {
                    $('#university_combo').fadeOut();
                    $('#university_combo').val();
                    $('#university_combo1').fadeOut();
                    $('#university_combo1').val();
                    $('#university_combo2').fadeIn();
                }
        }
</script>