#####################
Batch Text Replacer Demo ID:0206895
#####################
<?php

/**
 * clr_view
 * @package im
 * 

 * 
 * @version    2.2
 * 
 */

include("template/header.php");
require_once 'classes/transfer_request_form.php';

$education = new transfer_management();

$posting_form_id = $_GET['id'];
$result = $education->find_by_personal($posting_form_id);
 $qry_mw = "SELECT
	transfer_management.`current_date`,
	transfer_management.document_ref_number 
FROM   transfer_management 
WHERE  transfer_management.posting_form_no = '$posting_form_id'";
//echo $qry_mw; exit;
                    $qry1 = mysqli_query($conn, $qry_mw);
                    while ($result1 = mysqli_fetch_assoc($qry1)) {
//                        print_r($result1); exit;
                       $order_date = $result1['current_date'];
                        $ref_no = $result1['document_ref_number'];
                    }
                    $order_date = strtotime($order_date);
                    $order_date = date('d-m-Y',$order_date);

?>
<script>
//    function printContents() {
//        var dispSetting = "toolbar=yes,location=no,directories=yes,menubar=yes,scrollbars=yes, left=100, top=25";
//        var printingContents = document.getElementById("printing").innerHTML;
//
//        var docprint = window.open("", "", printing);
//
//
//        docprint.document.open();
//        docprint.document.write('<html><head><title>Transfer Letter</title>');
//
//        //setting up CSS for the watermark
//
//        docprint.document.write('</head><body onLoad="self.print();"><center>');
//        docprint.document.write(printingContents);
//        //docprint.document.write('<div id="watermark"><?php // echo $print_word;
                                                        ?>//</div>');
//        docprint.document.write('</center>');
//
//        docprint.document.write('</body></html>');
//        docprint.document.close();
//        docprint.focus();
//    }
</script>
</head>
<!-- END HEAD -->

<body class="page-header-fixed page-quick-sidebar-over-content">
    <!-- BEGIN HEADER -->
    <div class="page-container">
        <div class="page-content-wrapper">
            <div class="page-content">

                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-10">
                        <div class="widget">

                            <div class="widget-body">
                                <div id="printing" style="clear:both;margin-top:20px;">
                                    <div style="margin-left:25px !important; width:90% !important;">
                                        <style>
                                            body {
                                                margin: 0px !important;
                                                font-family: Arial, Helvetica, sans-serif;
                                            }

                                            table#myTable {
                                                margin-top: 20px;
                                                border-collapse: collapse;
                                                border-spacing: 0;
                                            }

                                            table#myTable tr td,
                                            table#myTable tr th {
                                                font-size: 11px;
                                                padding-left: 5px;
                                                text-align: left;
                                                border: 1px solid #999;
                                            }

                                            table#myTable tr td.TAR {
                                                text-align: right;
                                                padding: 5px;
                                                width: 50px !important;
                                            }

                                            .sb1NormalFont {
                                                color: #444444;
                                                font-family: Verdana, Arial, Helvetica, sans-serif;
                                                font-size: 11px;
                                                font-weight: bold;
                                                text-decoration: none;
                                            }

                                            p {
                                                margin-bottom: 5px;
                                                font-size: 11px !important;
                                                line-height: 1 !important;
                                                padding: 0 !important;
                                            }

                                            table#headerTable tr td {
                                                font-size: 11px;
                                            }

                                            /* Print styles */
                                            @media only print {

                                                table#myTable tr td,
                                                table#myTable tr th {
                                                    font-size: 8px;
                                                    padding-left: 2 !important;
                                                    text-align: left;
                                                    border: 1px solid #999;
                                                }

                                                #doNotPrint {
                                                    display: none !important;
                                                }
                                            }
                                        </style>

                                        <center>
                                            <table>
                                                <tr style="background-color:white">
                                                    <th><img src="common/theme/images/kp.png" style="width:80px" style="display:inline-block; " /></th>
                                                    <th style="float:right"></th>
                                                    <th>
                                                        <p style="color: #000000; font-size: 30px;text-align:center">
                                                            <span style="float:left; font-weight:normal;"><i style="color:black !important" onClick="history.go(-1)" class="fa fa-arrow-left" /></i></span>
                                                            <span style="font-weight:bold; text-decoration: underline; font-size: 1.4em ">GOVERNMENT OF KHYBER PAKHTUNKHWA<br>HEALTH DEPARTMENT</span>
                                                        </p>
                                                    </th>
                                                </tr>
                                            </table>
                                        </center>

                                        <br />
                                        <br />
                                        <h5 class="right">Dated Peshawar The <?php echo $order_date; ?></h5>
                                        <br />
                                        <br />
                                         <span style=" float:left;font-weight:bold; text-decoration: underline; font-size: 1em "><?php echo $ref_no; ?>/HR/Admin:-</span>&nbsp;&nbsp;<span style="font-size:1em">On the recommendation of Health Human Resource Committee (HHRC) meeting held on <?php echo $order_date ?>, after considering online applications submitted vide www.Healthkp.gov.pk , the following posting/transfer of doctors is ordered; with immediate effect, in the best public intrest.</span>
                                       <!--<div class="row"><div class="col-md-2"></div><div class="col-md-10">jcsklcklhclshclhslchlshsh</div></div>-->


                                        <p style="text-align:center;margin-right:35px;">
                                            <?php // echo "For $mainStk District $distName"; 
                                            ?>
                                        </p>
                                        <!--                                        <table width="200" id="headerTable" align="right">
                                            <tr>
                                                <td align="left"><p style="width: 100%; display: table;"> <span style="display: table-cell; width: 20px;">For: </span> <span style="display: table-cell; border-bottom: 1px solid black;"><?php // echo $duration; 
                                                                                                                                                                                                                                            ?></span> </p></td>
                                            </tr>
                                            <tr>
                                                <td><p style="width: 100%; display: table;"> <span style="display: table-cell; width: 75px;">Requisition No: </span> <span style="display: table-cell; border-bottom: 1px solid black;"><?php // echo $requisitionNum; 
                                                                                                                                                                                                                                        ?></span> </p></td>
                                            </tr>
                                            <tr>
                                                <td><p style="width: 100%; display: table;"> <span style="display: table-cell; width: 83px;">Requisition Date: </span> <span style="display: table-cell; border-bottom: 1px solid black;"><?php // echo $requestedOn; 
                                                                                                                                                                                                                                            ?></span> </p></td>
                                            </tr>
                                        </table>-->
                                        <div style="clear:both;"></div>
                                        <table width="98%" id="myTable" cellspacing="0" align="center">
                                            <thead>
                                                <tr>
                                                    <th style="width: 1%;" class="center">No.</th>
                                                    <th>Name & Designation</th>
                                                    <!--<th>Current District</th>-->
                                                    <th>From</th>
                                                    <!--<th>Current Designation</th>-->
                                                    <!--<th>Transfer To District</th>-->
                                                    <th>To</th>
                                                    <!--<th>Transfer To Designation</th>-->
                                                    <!--<th>Remarks</th>-->
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <!-- Table row -->
                                                <?php
                                                $count = 1;
                                                while ($row = $result->fetch_array()) {

                                                    $ccto = $row['cc_edit_box'];
                                                    $class = "gradeX";
                                                    if ($count % 2 == 0) {
                                                        $class = "gradeC";
                                                    }
                                                    //$attchment = new attachments();
                                                    //$att_count = $attchment->count_all($row['pk_id']);
                                                ?>
                                                    <tr class="<?php echo $class; ?>">
                                                        <td class="center"><?php echo $count; ?></td>
                                                        <td class="important"><?php echo $row['Doctor_Name']; ?><br><?php echo $row['current_designation']; ?></td>
                                                        <!--<td class="important"><?php echo $row['current_district']; ?></td>-->
                                                        <td class="important"><?php echo $row['current_office']; ?></td>
                                                        <!--<td class="important"><?php echo $row['current_designation']; ?></td>-->
                                                        <!--<td class="important"><?php echo $row['transfer_to_district']; ?></td>-->
                                                        <td class="important"><?php echo $row['transfer_to_office']; ?></td>
                                                        <!--<td class="important"><?php echo $row['transfer_to_designation']; ?></td>-->
                                                        <!--<td class="important"><?php echo $row['description']; ?></td>-->
                                                    </tr>
                                                <?php
                                                    $count++;
                                                }
                                                ?>
                                                <!-- // Table row END -->
                                                <!-- Table row -->

                                                <!-- // Table row END -->
                                            </tbody>
                                        </table>
                                         <span class="pull-right" style="float:right; font-weight: bold; font-size: 1.0em">&nbsp;&nbsp;SECRETARY HEALTH <br />KHYBER PAKHTUNKHWA</span>
                                       <br />
                                        <br />
                                        <br />
                                        <br />
                                        <!--<span style="font-weight:bold; text-decoration: underline; font-size: 1.1em; float:left ">Endst.of even No. &DATE</span>&nbsp;&nbsp;<span style="font-size:1em"></span>-->
                                        <p style="float:left; width:100%"><b>Copy forwarded to:</b></p>
                                        <p style="float:left; width:100%">
                                            <?php
                                            echo nl2br($ccto);
                                            //foreach($abc as $a) { 
                                            ?>
                                            <!--<b><p>1. Accountant Gneral Khyber Pakhtunkhwa Peshawar</p></b>-->
                                            <?php //} 
                                            ?>
                                        </p>
                                         <span class="pull-right" style="float:right; font-weight: bold; font-size: 0.9em">&nbsp;&nbsp;<?php echo $_SESSION['username'];?> <br />Section Officer (E-II)</span>
                                        <table width="100%">
                                            <!--                                            <tr>
                                                <td colspan="4">&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td colspan="4">&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="text-align:right;" width="10%" class="sb1NormalFont">Name:</td>
                                                <td width="40%">__________________________</td>
                                                <td width="30%" style="text-align:right;" class="sb1NormalFont">Signature:</td>
                                                <td width="20%">__________________________</td>
                                            </tr>
                                            <tr>
                                                <td colspan="4">&nbsp;</td>
                                            </tr>-->
                                            <!--                                            <tr>
                                                <td style="text-align:right;" class="sb1NormalFont">Designation:</td>
                                                <td>__________________________</td>
                                                <td style="text-align:right;" class="sb1NormalFont">Date:</td>
                                                <td>__________________________</td>
                                            </tr>-->
                                            <tr id="doNotPrint">
                                                <td colspan="4" style="text-align:right; border:none; padding-top:15px;">
                                                    <input type="button" onClick="history.go(-1)" value="Back" class="btn btn-primary" />
                                                    <input type="button" onClick="window.print()" value="Print" class="btn btn-warning" />
                                                </td>
                                            </tr>
                                        </table>

                                        <!--<div id="watermark" style="font-size:200px;font-color:#eeeee; opacity: 0.2;z-index: 5;right:50%;left:30%;top: 60%;position: absolute;display: block;   -ms-transform: rotate(340deg);  -webkit-transform: rotate(340deg);  transform: rotate(340deg);">Draft</div>-->

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END FOOTER -->

    <!-- END JAVASCRIPTS -->
</body>
<!-- END BODY -->

</html>
<?php
include("template/footer.php");

#####################
Batch Text Replacer Demo ID:365303
#####################
