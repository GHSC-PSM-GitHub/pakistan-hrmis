<?php
include 'template/header.php';
require_once 'classes/specialities.php';
require_once 'classes/training.php';
require_once 'classes/personal.php';
require_once 'classes/childrens.php';
require_once 'classes/post.php';
require_once 'classes/locations.php';
require_once 'classes/university.php';
require_once 'classes/category.php';
require_once 'classes/cadre.php';
require_once 'classes/degree.php';
require_once 'classes/warehouse.php';
require_once 'classes/config.php';
require_once 'classes/mode_of_appointment.php';
require_once 'classes/sanctioned_desg.php';
require_once 'classes/quota.php';
require_once 'classes/marital_status.php';
require_once 'classes/personal_status.php';
require_once 'classes/transfer_status.php';
require_once 'classes/setting.php';
?>
<style>
    .error {
      color: red;
      background-color: #DAFBDA;
   }
    </style>
<!-- Content -->
<div id="content">
    <!-- Breadcrumb -->
    <ul class="breadcrumb">
        <li><a href="personal_record.php" class="glyphicons user"><i></i>Personal Record</a></li>
        <li class="divider"></li>
        <li>Add New</li>
    </ul>
    <div class="separator bottom"></div>
    <!-- // Breadcrumb END -->
    <?php if (isset($_GET['status']) && $_GET['status'] == 'status') { ?>
        <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong>Success!</strong> Status has been updated successfully!
        </div>
    <?php } ?>
    <?php if (isset($_GET['status']) && $_GET['status'] == 'file') { ?>
        <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <?php echo $_SESSION['msg']; ?>
        </div>
    <?php } ?>
    <?php if (isset($_GET['status']) && $_GET['status'] == 'forbidden') { ?>
        <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong>Forbidden!</strong> You don't have permission to do this! Please contact your administrator!
        </div>
    <?php } ?>
    <!-- Heading -->
    <!--    <div class="heading-buttons">
            <h3>Human Resource - Khyber Pakhtunkhwa</h3>
            
            <div class="clearfix"></div>
        </div>-->
    <div class="separator bottom"></div>
    <!-- // Heading END -->

    <div class="innerLR">
        <!-- Widget -->
        <div class="widget personal row-fluid" data-toggle="collapse-widget">

            <!-- Widget heading -->
            <div class="widget-head">
                <h3 class="heading">Add Personal Record</h3>
            </div>
            <!-- // Widget heading END -->

            <div class="widget-body">
                <form method="post" id="addpersonalform" name="addpersonalform">
                    <div class="row-fluid">
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="gender" required>Gender <span style="color: red">*</span> </label>
                                <div class="controls">
                                    <select class="span12" id="gender" name="gender" required>
                                        <option value="">Select</option>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="name">Name <span style="color: red">*</span> (Min three Characters)</label>
                                <div class="controls"><input class="span12" id="name" name="name" minlength="2" type="text" required /></div>
                            </div>
                        </div>
                        <div class="span4">
                            <div class="control-group ">
                                <label class="control-label" for="father_name">Father Name </label>
                                <div class="controls"><input class="span12" minlength="2" id="father_name" name="father_name" type="text" /></div>
                            </div>
                        </div>

                    </div>
                    <div class="row-fluid">
                        <div class="span4">
                            <div class="control-group hide" id="divhusband_id">
                                <label class="control-label" for="husband_name">Husband Name </label>
                                <div class="controls"><input class="span12" minlength="2" id="husband_name" name="husband_name" type="text" /></div>
                            </div>
                        </div>

                    </div>
                    <div class="row-fluid">
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="cnic">CNIC <span style="color: red" id="user">*</span> (13 Characters like 00000-0000000-0) </label>
                                <div class="controls"><input class="span12" id="cnic" name="cnic" placeholder="00000-0000000-0" type="text" onchange="if (!cnicIsValid(this.value))
                                            alert('Please enter valid CNIC i.e. 00000-0000000-0');
                                        this.focus();" required /></div>
                            </div>
                        </div>

                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="date_of_birth">Date of Birth (dd/mm/yyyy) <span style="color: red">*</span></label>
                                <div class="controls"><input class="span12" id="date_of_birth" placeholder="DD/MM/YYYY" name="date_of_birth" type="text" required /></div>
                            </div>
                        </div>
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="marital_status">Marital Status (Single / Married) <span style="color: red">*</span></label>
                                <div class="controls">
                                    <select class="span12" id="marital_status" name="marital_status" required>
                                        <option value="">Select</option>
                                        <?php
                                        $location = new marital_status();
                                        $result = $location->maritaldropdown();
                                        while ($row = $result->fetch_assoc()) {
                                        ?>
                                            <option value="<?php echo $row['marital_status']; ?>"><?php echo $row['marital_status']; ?></option>
                                        <?php
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row-fluid">
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="district_of_domicile">District of Domicile <span style="color: red">*</span></label>
                                <div class="controls">
                                    <select class="span12 select2" id="district_of_domicile" name="district_of_domicile" required>
                                        <option value="">Select</option>
                                        <?php
                                        $location = new locations();
                                        $result = $location->districtdropdown();
                                        while ($row = $result->fetch_assoc()) {
                                        ?>
                                            <option value="<?php echo $row['pk_id']; ?>"><?php echo $row['location_name']; ?></option>
                                        <?php
                                        }
                                        ?>
                                    </select></div>
                            </div>
                        </div>
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="postal_address">Postal Address <span style="color: red">*</span></label>
                                <div class="controls"><input class="span12" id="postal_address" name="postal_address" type="text" required /></div>
                            </div>
                        </div>
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="residential_address">Residential/Temporary Address </label>
                                <div class="controls"><input class="span12" id="residential_address" name="residential_address" type="text" /></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row-fluid">
                        
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="residential_city">Residential/Temporary City <span style="color: red">*</span></label>
                                <div class="controls">
                                    <select class="span12 select2" id="residential_city" name="residential_city" required>
                                        <option value="">Select</option>
                                        <?php
                                        $location = new locations();
                                        $result = $location->districtdropdown();
                                        while ($row = $result->fetch_assoc()) {
                                        ?>
                                            <option value="<?php echo $row['pk_id']; ?>"><?php echo $row['location_name']; ?></option>
                                        <?php
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="current_address">Permanent Address </label>
                                <div class="controls"><input class="span12" id="current_address" name="current_address" type="text" /></div>
                            </div>
                        </div>
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="current_city">Permanent City <span style="color: red">*</span></label>
                                <div class="controls">
                                    <select class="span12 select2" id="current_city" name="current_city" required>
                                        <option value="">Select</option>
                                        <?php
                                        $location = new locations();
                                        $result = $location->districtdropdown();
                                        while ($row = $result->fetch_assoc()) {
                                        ?>
                                            <option value="<?php echo $row['pk_id']; ?>"><?php echo $row['location_name']; ?></option>
                                        <?php
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                       <div class="row-fluid"> 
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="contact_no">Contact No <span style="color: red">*</span> (11 Digits like 03XXXXXXXXX)</label>
                                <div class="controls"><input class="span12" id="contact_no" name="contact_no" placeholder="03XXXXXXXXX" type="text" required /></div>
                            </div>
                        </div>
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="email">Email </label>
                                <div class="controls"><input class="span12" id="email" placeholder="info@xyz.com" name="email" type="text" onchange="if (!emailIsValid(this.value))
                                            alert('Please enter valid email');
                                        this.focus()" /></div>
                            </div>
                        </div>
                        
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="contact_no">Nationality <span style="color: red">*</span></label>
                                <div class="controls">
                                    <select class="span12" id="nationality" name="nationality[]" required multiple>
                                    <?php   
                                    $query = "select * from countries";
                                    $result = mysqli_query($conn, $query);

                                    while($row = mysqli_fetch_assoc($result))
                                         { ?> 
                                                <option value="<?php echo $row['country_name'] ?>" <?php echo ($row['country_name'] == "Pakistan " ? 'selected="selected"' : '') ?>><?php echo $row['country_name'] ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                       </div>
                    <div class="row-fluid"> 
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="email">Passport # </label>
                                <div class="controls"><input class="span12" id="pass_no" name="pass_no" type="text" /></div>
                            </div>
                        </div>
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="pmdc_registration">Professional Reg# (If Applicable)</label>
                                <div class="controls"><input class="span12" id="pmdc_registration" name="pmdc_registration" type="text" value="nil" /></div>
                            </div>
                        </div>
                    </div>
                    <div class="row-fluid">
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="employee_number">Personal/Employee Number <span style="color: red">*</span></label>
                                <div class="controls"><span id="user"></span><input class="span12" id="employee_number" name="employee_number" type="text" onchange="duplicate_emp_number(this.value);" required /></div>
                            </div>
                        </div>
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="status_two">Job Status <span style="color: red">*</span></label>
                                <div class="controls">
                                    <select class="span12" id="status_two" name="status_two" required>
                                        <option value="">Select</option>
                                        <?php
                                        $location = new personal_status();
                                        $result = $location->personalstatusdropdown();
                                        while ($row = $result->fetch_assoc()) {
                                        ?>
                                            <option value="<?php echo $row['personal_status']; ?>"><?php echo $row['personal_status']; ?></option>
                                        <?php
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="joining_date">Joining Date <span style="color: red">*</span></label>
                                <div class="controls"><input class="span12" id="joining_date" name="joining_date" type="text" required /></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row-fluid">
                    <?php
                    $list = new post();
                    $result = $list->postdropdown();

                    $rowCount = $result->num_rows;
                    ?>
                    <div class="span4">
                        <div class="control-group">
                            <label class="control-label" for="actual_desg">Actual Designation <span style="color: red">*</span></label>
                            <div class="controls">
                                <select class="span12 select2" name="actual_desg" id="actual_desg" required>
                                    <option value="">Select</option>

                                    <?php
                                    if ($rowCount > 0) {

                                        while ($row = $result->fetch_array()) {

                                            echo '<option value="' . $row['pk_id'] . '">' . $row['name'] . '</option>';
                                        }
                                    } else {
                                        echo '<option value="">Post not available</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                    </div>
                        
                    <?php
                    $list = new post();
                    $result = $list->sancpostdropdown();

                    $rowCount = $result->num_rows;
                    ?>
                    <div class="span4" id="sancdesg_combo">
                        <div class="control-group">
                            <label class="control-label" for="sancpost">Sanctioned Designation <span style="color: red">*</span></label>
                            <select name="sancpost" id="sancpost" class="span12 select2" required>
                                    <option value="">Select</option>

                                    <?php
                                    if ($rowCount > 0) {

                                        while ($row = $result->fetch_array()) { ?>
                                            <option value=<?php echo $row['pk_id'];?> ><?php echo $row['name'];?></option>
                                       <?php }
                                    } else {
                                        echo '<option value="">Post not available</option>';
                                    }
                                    ?>
                                </select>
                        </div>
                    </div>
                        
                    <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="quota">Current BPS <span style="color: red">*</span></label>
                                <div class="controls">
                                    <select class="span12" id="bps" name="bps" required>
                                        <?php $default = 17;
                                        for($i=1; $i<=22; $i++) { ?>
                                        <option value="<?php echo $i; ?>" <?php if($default == $i) { echo "selected="; }?>><?php echo $i; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    <div class="row-fluid">
                        <?php
                            $list = new appointment();
                            $result = $list->appointmentdropdown();
                            if($result)
                            {
                                $rowCount = $result->num_rows;
                            }
                        ?>
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="mod_app">Mode of Appointment <span style="color: red">*</span></label>
                                <div class="controls">
                                    <select class="span12" id="mod_app" name="mod_app" required>
<!--                                        <option value="New">New</option>
                                        <option value="Initial">Initial</option>
                                        <option value="Merit">Merit</option>
                                        <option value="By Transfer">By Transfer</option>-->
                                        <!--<option value="By Deputation">By Deputation</option>-->
                                        <?php
                                        if ($rowCount > 0) {
                                                
                                            while ($row = $result->fetch_array()) {
                                                $sel = "";
                                                if ($data["mod_app"] == $row['pk_id']) {
                                                    $sel = "selected=selected";
                                                }?>

                                                <option value="<?php echo $row['pk_id'] ?>" <?php echo $sel?>> <?php echo $row['appointment_type'] ?> </option>
                                           <?php }
                                        } else {
                                            echo '<option value="">Data not available</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <?php
                        $list = new quota();
                        $result = $list->quotadropdown();

                        $rowCount = 0;
                        if (isset($result) && !empty($result))
                            $rowCount = $result->num_rows;
                        ?>
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="quota">Quota <span style="color: red">*</span></label>
                                <div class="controls">
                                    <select class="span12" id="quota" name="quota" required>
<!--                                        <option value="Merit">Merit</option>
                                        <option value="Disbale">Disbale</option>
                                        <option value="Minority">Minority</option>
                                        <option value="Decease">Decease</option>
                                        <option value="Medical ground">Medical ground</option>
                                        <option value="Gender">Gender</option>-->
                                        <option value="">Select</option>
                                      <?php
                                        if ($rowCount > 0) {
                                                
                                            while ($row = $result->fetch_array()) {
                                                $sel = "";
                                                if ($data["quota"] == $row['quota']) {
                                                    $sel = "selected=selected";
                                                }?>

                                                <option value="<?php echo $row['quota'] ?>" <?php echo $sel?>> <?php echo $row['quota'] ?> </option>
                                           <?php }
                                        } else {
                                            echo '<option value="">Data not available</option>';
                                        } ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="span4">

                            <!-- Group -->
                            <?php
                            $list = new cadre();
                            $result = $list->cadredropdown();

                            $rowCount = $result->num_rows;
                            ?>
                            <div class="control-group">
                                <label class="control-label" for="cadre_value">Cadre Value <span style="color: red">*</span></label>
                                <select class="span" name="cadre_value" id="cadre_value" required>
                                    <option value="">Select</option>

                                    <?php
                                    if ($rowCount > 0) {

                                        while ($row = $result->fetch_array()) {

                                            echo '<option value="' . $row['pk_id'] . '">' . $row['cadre_value'] . '</option>';
                                        }
                                    } else {
                                        echo '<option value="">Cadre not available</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                    </div>
                        
                    <div class="row-fluid">
                        
                        <div class="span4">

                            <!-- Group -->
                            <?php
                            $list = new category();
                            $result = $list->categorydropdown();

                            $rowCount = $result->num_rows;
                            ?>
                            <div class="control-group">
                                <label class="control-label" for="category_value">Employee Service Type <span style="color: red">*</span></label>
                                <select class="span" name="category_value" id="category_value" required>
                                    <option value="">Select</option>

                                    <?php
                                    if ($rowCount > 0) {

                                        while ($row = $result->fetch_array()) {

                                            echo '<option value="' . $row['category_value'] . $row['pk_id'] . '">' . $row['category_value'] . '</option>';
                                        }
                                    } else {
                                        echo '<option value="">Category not available</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                         <?php
                        $list = new warehouse();
                        $result = $list->postingplacedropdown();

                        $rowCount = 0;
                        if (isset($result) && !empty($result))
                            $rowCount = $result->num_rows;
                        ?>
<!--                        <div class="span4" id="dofficehide" style="display: none;">
                            <div class="control-group">
                                <label class="control-label" for="sel_office">Select Office</label>
                                <div class="controls">
                                    <select class="span12" name="sel_office" id="sel_office">
                                        <option value="">Select</option>

                                        <?php
//                                        if ($rowCount > 0) {
//
//                                            while ($row = $result->fetch_array()) {
//
//                                                echo '<option value="' . $row['wh_name']  . '">' . $row['wh_name'] . '</option>';
//                                            }
//                                        } else {
//                                            echo '<option value="">District not available</option>';
//                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                        </div>-->
                        
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="seniority_number">Seniority List Number </label>
                                <div class="controls"><input class="span12" id="seniority_number" name="seniority_number" type="text" /></div>
                            </div>
                        </div>
                        
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="ddo_number">DDO Number </label>
                                <div class="controls"><input class="span12" id="ddo_number" name="ddo_number" type="text" /></div>
                            </div>
                        </div>
                    </div>
                    <div class="row-fluid">
                        <div class="span4">
                                <div class="control-group">
                                    <label class="control-label" for="ddo_description">DDO Description </label>
                                    <div class="controls"><input class="span12" id="ddo_description" name="ddo_description" type="text" /></div>
                                </div>
                        </div>
                    </div>
                    <div class="row-fluid">                        
                        <div class="span12 right">
                            <div class="control-group">
                                <div class="controls"><button type="button" id="personalbutton" class="btn btn-primary">Save & Next</button></div>
                            </div>
                        </div>

                    </div>
                </form>
            </div>
        </div>

        <div class="widget education row-fluid" data-toggle="collapse-widget" data-collapse-closed="true">

            <!-- Widget heading -->
            <div class="widget-head">
                <h3 class="heading">Educational Record</h3>
            </div>
            <!-- // Widget heading END -->

            <div class="widget-body">
                <form id="educationform" name="educationform" method="post">
                    <div class="row-fluid">

                        <!-- Column -->
                        
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="type">Select Level</label>
                                <select class="span" name="type" id="type">
                                    <option value="">Select</option>
                                    <option value="1">Primary</option>
                                    <option value="2">Middle</option>
                                    <option value="3">SSC / (O/A Levels)</option>
                                    <option value="4">HSSC / DAE</option>
                                    <option value="5">Bachelor's Degree</option>
                                    <option value="6">Master's Degree</option>
                                    <option value="7">Phd</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="span4" id="university_combo" style="display: none">

                            <!-- Group -->
                            <?php
                            $list = new university();
                            $result = $list->universitydropdown();

                            $rowCount = $result->num_rows;
                            ?>
                            <div class="control-group">
                                <label class="control-label" for="university_id">School Name</label>
                                <!--<div class="controls"><input class="span12" id="university_id" name="university_id" type="text" /></div>-->
                                <select class="span" name="university_id" id="university_id">
                                    <option value="">Select</option>
                                    
                                    <?php
                                    if ($rowCount > 0) {

                                        while ($row = $result->fetch_array()) {

                                            echo '<option value="' . $row['pk_id'] . '">' . $row['university_name'] . '</option>';
                                        }
                                    } else {
                                        echo '<option value="">University not available</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="span4" id="university_combo1" style="display: none">
                            <!-- Group -->
                            <?php
                            $list = new university();
                            $result = $list->universitydropdown();

                            $rowCount = $result->num_rows;
                            ?>
                            <div class="control-group">
                                <label class="control-label" for="university_id">College / University Name</label>
                                <!--<div class="controls"><input class="span12" id="university_id" name="university_id1" type="text" /></div>-->
                                <select class="span" name="university_id1" id="university_id">
                                    <option value="">Select</option>
                                    
                                    <?php
                                    if ($rowCount > 0) {

                                        while ($row = $result->fetch_array()) {

                                            echo '<option value="' . $row['pk_id'] . '">' . $row['university_name'] . '</option>';
                                        }
                                    } else {
                                        echo '<option value="">University not available</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="span4" id="university_combo2" style="display: none">
                            <!-- Group -->
                            <?php
                            $list = new university();
                            $result = $list->universitydropdown();

                            $rowCount = $result->num_rows;
                            ?>
                            <div class="control-group">
                             <label class="control-label" for="university_id">University Name</label>
                             <!--<div class="controls"><input class="span12" id="university_id" name="university_id2" type="text" /></div>-->
                            <select class="span" name="university_id2" id="university_id">
                                    <option value="">Select</option>
                                    
                                    <?php
                                    if ($rowCount > 0) {

                                        while ($row = $result->fetch_array()) {

                                            echo '<option value="' . $row['pk_id'] . '">' . $row['university_name'] . '</option>';
                                        }
                                    } else {
                                        echo '<option value="">University not available</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="span4" id="degree_level">

                            
                        </div>
                    </div>
                    <div class="row-fluid">
<!--                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="start_date">Start Date </label>
                                <div class="controls"><input class="span12" id="start_date" name="start_date" type="text" /></div>
                            </div>
                        </div>
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="completion_date">Completion Date </label>
                                <div class="controls"><input class="span12" id="completion_date" name="completion_date" type="text" /></div>
                            </div>
                        </div>-->
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="e_month">Ending Month</label>
                                <select class="span" id="e_month" name="e_month" >
                                    <?php for ($m = 1; $m <= 12; $m++) {
                                        $sel = "";
                                        if ($m == $e_month) {
                                            $sel = "selected=selected";
                                        }
                                    ?>
                                        <option value="<?php echo $m; ?>" <?php echo $sel; ?>><?php echo date('F', mktime(0, 0, 0, $m, 10)); ?></option>
                                    <?php } ?>
                                </select>
                                <!--<div class="controls"><input class="span12" id="percentage" name="percentage" type="text" /></div>-->
                            </div>
                        </div>
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="e_year">Ending Year</label>
                                <!--<div class="controls"><input class="span12" id="percentage" name="percentage" type="text" /></div>-->
                                <select class="span" id="e_year" name="e_year" >
                                    <?php for ($y = 1950; $y <= date("Y"); $y++) {
                                        $sel = "";
                                        if ($y == $e_year) {
                                            $sel = "selected=selected";
                                        }
                                    ?>
                                        <option value="<?php echo $y; ?>" <?php echo $sel; ?>><?php echo $y; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="e_gpa">Total GPA</label>
                                <div class="controls"><input class="span12" id="e_gpa" name="e_gpa" type="text" /></div>
                            </div>
                        </div>

                    </div>
                    <div class="row-fluid">
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="e_gpa">Obtained GPA</label>
                                <div class="controls"><input class="span12" id="obtain_gpa" name="obtain_gpa" type="text" /></div>
                            </div>
                        </div>
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="total_marks">Total Marks</label>
                                <div class="controls"><input class="span12" id="total_marks" name="total_marks" type="text" /></div>
                            </div>
                        </div>
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="total_marks">Obtained Marks</label>
                                <div class="controls"><input class="span12" id="obtain_marks" name="obtain_marks" type="text" /></div>
                            </div>
                        </div>
<!--                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="cgpa">Cgpa</label>
                                <div class="controls"><input class="span12" id="cgpa" name="cgpa" type="text" /></div>
                            </div>
                        </div>
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="hec_attestation_no">Hec Attestation No</label>
                                <div class="controls"><input class="span12" id="hec_attestation_no" name="hec_attestation_no" type="text" /></div>
                            </div>
                        </div>
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="attestation_date">Attestation Date</label>
                                <div class="controls"><input class="span12" id="attestation_date" name="attestation_date" type="text" /></div>
                            </div>
                        </div>-->
                        
                    </div>
                    <div class="row-fluid">
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="percentage">Percentage</label>
                                <div class="controls"><input class="span12" id="percentage" name="percentage" type="text" /></div>
                            </div>
                        </div>
                    </div>

                    <div class="row-fluid">
                        <div class="span12 right">
                            <div class="control-group">
                                <!--<label class="control-label" for="educationbutton">&nbsp;</label>-->
                                <div class="controls"><button type="button" id="educationbutton" class="btn btn-primary">Add</button></div>
                            </div>
                        </div>
                    </div>

                    <!-- // Column END -->
                    <input type="hidden" id="personal_id" name="personal_id" value="" />

                </form>

                <div class="row-fluid">
                    <div class="span12" id="education_data">

                    </div>
                </div>
            </div>
        </div>

        <div class="widget row-fluid" data-toggle="collapse-widget" data-collapse-closed="true">

            <!-- Widget heading -->
            <div class="widget-head">
                <h3 class="heading">Specialities Record</h3>
            </div>
            <!-- // Widget heading END -->

            <div class="widget-body">

                <form name="specilityform" id="specilityform" method="post">
                    <div class="row-fluid">

                        <div class="span8">

                            <!-- Group -->

                            <?php
                            $list = new speciality();
                            $result = $list->specilitydropdown();

                            $rowCount = $result->num_rows;
                            ?>
                            <div class="control-group">
                                <label class="control-label" for="specility">Specility</label>
                                <select class="span6" name="specility" id="specility">
                                    <option value="">Select</option>

                                    <?php
                                    if ($rowCount > 0) {

                                        while ($row = $result->fetch_array()) {

                                            echo '<option value="' . $row['pk_id'] . '">' . $row['specility'] . '</option>';
                                        }
                                    } else {
                                        echo '<option value="">Specility not available</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="specilitybutton">&nbsp;</label>
                                <div class="controls"><button type="button" id="specilitybutton" class="btn btn-primary">Add</button></div>
                            </div>
                        </div>
                    </div>

                    <input type="hidden" id="pers_specility_id" name="pers_specility_id" value="" />
                </form>
                <div class="row-fluid">
                    <div class="span12" id="specility_data">

                    </div>
                </div>


            </div>
            <!-- // Column END -->



        </div>


        <div class="widget row-fluid" data-toggle="collapse-widget" data-collapse-closed="true">

            <!-- Widget heading -->
            <div class="widget-head">
                <h3 class="heading">Training / Certification Record</h3>
            </div>
            <!-- // Widget heading END -->

            <div class="widget-body">
                <div class="row-fluid">
                    <form name="trainingform" id="trainingform" method="post">
                        <div class="span3">

                            <?php
                            $list = new training();
                            $result = $list->trainingdropdown();

                            $rowCount = $result->num_rows;
                            ?>
                            <div class="control-group">
                                <label class="control-label" for="training">Training / Certification</label>
                                <select class="span12" name="training" id="training" required>
                                    <option value="">Select</option>

                                    <?php
                                    if ($rowCount > 0) {

                                        while ($row = $result->fetch_array()) {

                                            echo '<option value="' . $row['pk_id'] . '">' . $row['title'] . '</option>';
                                        }
                                    } else {
                                        echo '<option value="">Trainings not available</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
<!--                        <div class="span4">
                             <div class="control-group">
                                 <label class="control-label" for="training_date">Training Date</label>
                                 <div class="controls"><input class="span" id="training_date" name="training_date" type="text" /></div>
                             </div>
                         </div>-->
                        <div class="span3">
                          <div class="control-group">
                              <label class="control-label" for="years">Start Years </label>
                              <select class="span12" onchange="calculate_age(this.value,'dob2age')" id="start_year" name="start_year" >
                                <?php for ($y = 1950; $y <= date("Y"); $y++) {
                                    $sel = "";
                                    if ($y == $age['0']) {
                                        $sel = "selected=selected";
                                    }
                                ?>
                                    <option value="<?php echo $y; ?>" <?php echo $sel; ?>><?php echo $y; ?></option>
                                <?php } ?>
                            </select>
                          </div>
                        </div>
                        <div class="span3">
                          <div class="control-group">
                              <label class="control-label" for="months">Start Months </label>
                             <select class="span12" onchange="calculate_age(this.value,'dob2age')" id="start_month" name="start_month" >
                                <?php for ($m = 1; $m <= 12; $m++) {
                                    $sel = "";
                                    if ($m == $age['1']) {
                                        $sel = "selected=selected";
                                    }
                                ?>
                                    <option value="<?php echo $m; ?>" <?php echo $sel; ?>><?php echo date('F', mktime(0, 0, 0, $m, 10)); ?></option>
                                <?php } ?>
                            </select>
                          </div>
                        </div>
                        <div class="span3">
                            <div class="control-group">
                                <label class="control-label" for="trainingbutton">&nbsp;</label>
                                <div class="controls"><button type="button" id="trainingbutton" class="btn btn-primary">Add</button></div>
                            </div>
                        </div>
                </div>

                <input type="hidden" id="pers_training_id" name="pers_training_id" value="" />
                </form>
                <div class="row-fluid">
                    <div class="span12" id="training_data">

                    </div>
                </div>

            </div>
            <!-- // Column END -->



        </div>

        <div class="widget row-fluid" data-toggle="collapse-widget" data-collapse-closed="true">

            <!-- Widget heading -->
            <div class="widget-head">
                <h3 class="heading">Spouse Record</h3>
            </div>
            <!-- // Widget heading END -->

            <div class="widget-body">
                <form name="spouseform" id="spouseform" method="post">

                    <div class="row-fluid">
                        <div class="span2">
                            <div class="control-group">
                                <label class="control-label" for="health_professional">Government Employee</label>
                                <div class="controls">
                                    <select class="span12" id="is_health_professional" name="is_health_professional">
                                        <option value="">Select</option>
                                        <option value="Yes">Yes</option>
                                        <option value="No">No</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="span3">
                            <div class="control-group">
                                <label class="control-label" for="spouse_name">Enter Spouse Name</label>
                                <div class="controls">
                                    <input name="spouse_name" id="spouse_name" type="text" class="form-controls span12" value="" />

                                </div>
                            </div>
                        </div>
                        <div class="span3 hide" id="divfamily_id">
                            <div class="control-group">
                                <label class="control-label" for="spouse_office">Office</label>
                                <div class="controls">
                                    <input name="spouse_office" id="spouse_office" type="text" class="form-controls span12" value="" />
                                </div>
                            </div>
                        </div>
                        <div class="span3 hide" id="divfamily_id2">
                            <div class="control-group">
                                <label class="control-label" for="spouse_designation">Designation</label>
                                <div class="controls">
                                    <input name="spouse_designation" id="spouse_designation" type="text" class="form-controls span12" value="" />
                                </div>
                            </div>
                        </div>


                        <div class="span1">
                            <div class="control-group">
                                <label class="control-label" for="spousebutton">&nbsp;</label>
                                <div class="controls"><button type="button" id="spousebutton" class="btn btn-primary">Add</button></div>
                            </div>
                        </div>

                    </div>
                    <!-- // Column END -->

                    <input type="hidden" id="pers_spouse_id" name="pers_spouse_id" value="" />
                </form>
                <div class="row-fluid">
                    <div class="span12" id="spouse_data">

                    </div>
                </div>

            </div>
        </div>


        <div class="widget row-fluid" data-toggle="collapse-widget" data-collapse-closed="true">

            <!-- Widget heading -->
            <div class="widget-head">
                <h3 class="heading">Children's Record</h3>
            </div>
            <!-- // Widget heading END -->

            <div class="widget-body">
                <form name="childrenform" id="childrenform" method="post">

                    <div class="row-fluid">
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="name">Name</label>
                                <div class="controls"><input class="span12" id="name" name="name" type="text" /></div>
                            </div>
                        </div>
                        <div class="span3">
                            <div class="control-group">
                                <label class="control-label" for="date_of_birth">Date of Birth</label>
                                <div class="controls"><input class="span12" id="child_dob" name="child_dob" type="text" /></div>
                            </div>
                        </div>
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="school_name">School Name</label>
                                <div class="controls"><input class="span12" id="school_name" name="school_name" type="text" /></div>
                            </div>
                        </div>
                        <div class="span1 right">
                            <div class="control-group">
                                <label class="control-label" for="childrenbutton">&nbsp;</label>
                                <div class="controls"><button type="button" id="childrenbutton" class="btn btn-primary">Add</button></div>
                            </div>
                        </div>
                    </div>
                    
                    <input type="hidden" id="pers_children_id" name="pers_children_id" value="" />
                    <input type="hidden" id="family_children_id" name="family_children_id" value="" />
                </form>
                <div class="row-fluid">
                    <div class="span12" id="children_data">

                    </div>
                </div>

            </div>
            <!-- // Column END -->
        </div>

        <div class="widget row-fluid" data-toggle="collapse-widget" data-collapse-closed="true">

            <!-- Widget heading -->
            <div class="widget-head">
                <h3 class="heading">Posting Record</h3>
            </div>
            <!-- // Widget heading END -->

            <div class="widget-body">
                <form name="postform" id="postform" method="post" enctype="multipart/form-data">
                    <div class="row-fluid">
                        
                        <?php
                        $list = new setting();
                        $result = $list->find_all();
                        while ($row = $result->fetch_array()) {
                            $remove_post_limit_id = $row['remove_post_limit'];
                            $pk_id = $row['pk_id'];
                        }
                        
                        
                        if($_SESSION['role'] == '1' || $_SESSION['role'] == '2')
                        {
                        $list = new post();
                        $result = $list->postdropdown();

                        $rowCount = $result->num_rows;
                        ?>
                        <div class="span3">
                            <div class="control-group">
                                <label class="control-label" for="post">Post name</label>
                                <div class="controls">
                                    <select class="span12 select2" name="post_id" id="post_id"  >
                                        <option value="">Select</option>

                                        <?php
                                        if ($rowCount > 0) {

                                            while ($row = $result->fetch_array()) {

                                                echo '<option value="' . $row['pk_id'] . '">' . $row['name'] . '</option>';
                                            }
                                        } else {
                                            echo '<option value="">Post not available</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="span3">
                            <div class="control-group">
                                <label class="control-label" for="pay_scale">Pay Scale </label>
                                <div class="controls">
                                    <select class="span12" id="pay_scale" name="pay_scale">
                                        <?php $default = 17;
                                        for($i=1; $i<=22; $i++) { ?>
                                        <option value="<?php echo $i; ?>" <?php if($default == $i) { echo "selected="; }?>><?php echo $i; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <label for="chkposting">
                                    <input type="checkbox" name="removepostlimit" id="removepostlimit" value="<?php if (isset($pk_id)) echo $pk_id; ?>" <?php if (isset($remove_post_limit_id) && $remove_post_limit_id == '1') {  echo 'checked="true"';}?> />
                                        Remove Limitation On District Users
                                </label>
                            </div>
                        </div>
                        
                        <?php } else if(($_SESSION['role'] == '4' || $_SESSION['role'] == '5') && $remove_post_limit_id == '1')
                        {
                        $list = new post();
                        $result = $list->postdropdownlimit();

                        $rowCount = $result->num_rows;
                        ?>
                        <div class="span3">
                            <div class="control-group">
                                <label class="control-label" for="post">Post name</label>
                                <div class="controls">
                                    <select class="span12 select2" name="post_id" id="post_id"  >
                                        <option value="">Select</option>

                                        <?php
                                        if ($rowCount > 0) {

                                            while ($row = $result->fetch_array()) {

                                                echo '<option value="' . $row['pk_id'] . '">' . $row['name'] . '</option>';
                                            }
                                        } else {
                                            echo '<option value="">Post not available</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="span3">
                            <div class="control-group">
                                <label class="control-label" for="pay_scale">Pay Scale </label>
                                <div class="controls">
                                    <select class="span12" id="pay_scale" name="pay_scale">
                                        <?php $default = 7;
                                        for($i=1; $i<=7; $i++) { ?>
                                        <option value="<?php echo $i; ?>" <?php if($default == $i) { echo "selected="; }?>><?php echo $i; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <?php } else if(($_SESSION['role'] == '4' || $_SESSION['role'] == '5') && $remove_post_limit_id == '0')
                        {
                        $list = new post();
                        $result = $list->postdropdown();

                        $rowCount = $result->num_rows;
                        ?>
                        <div class="span3">
                            <div class="control-group">
                                <label class="control-label" for="post">Post name</label>
                                <div class="controls">
                                    <select class="span12 select2" name="post_id" id="post_id"  >
                                        <option value="">Select</option>

                                        <?php
                                        if ($rowCount > 0) {

                                            while ($row = $result->fetch_array()) {

                                                echo '<option value="' . $row['pk_id'] . '">' . $row['name'] . '</option>';
                                            }
                                        } else {
                                            echo '<option value="">Post not available</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="span3">
                            <div class="control-group">
                                <label class="control-label" for="pay_scale">Pay Scale </label>
                                <div class="controls">
                                    <select class="span12" id="pay_scale" name="pay_scale">
                                        <?php $default = 17;
                                        for($i=1; $i<=22; $i++) { ?>
                                        <option value="<?php echo $i; ?>" <?php if($default == $i) { echo "selected="; }?>><?php echo $i; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <?php } ?>
                        
                         <?php
                        $list = new sanctioned_desg();
                        $result = $list->sanctioneddropdown();
                            if($result)
                            {
                                $rowCount = $result->num_rows;

                            }
                        ?>
                        <div class="span3">
                            <div class="control-group">
                                <label class="control-label" for="post">Sanctioned Name</label>
                                <div class="controls">
                                    <select class="span12" name="sanc_id" id="sanc_id" disabled="" >
                                        <option value="">Select</option>

                                        <?php
                                        if ($rowCount > 0) {

                                            while ($row = $result->fetch_array()) {

                                                echo '<option value="' . $row['pk_id'] . '">' . $row['sanctioned_desg'] . '</option>';
                                            }
                                        } else {
                                            echo '<option value="">Sanctioned designation not available</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <label for="chkposting">
                                <input type="checkbox" name="chkposting" id="chkposting" checked="true" />
                                Currently working on Post
                            </label>
                        </div>
                        <?php
                        $list = new warehouse();
                        $result = $list->postingplacedropdown();

                        $rowCount = $result->num_rows;
                        ?>
                        <div class="span3">
                            <div class="control-group">
                                <label class="control-label" for="kpdistrict">Posting place</label>
                                <div class="controls">
                                    <select class="span12" name="post_place_id" id="post_place_id">
                                        <option value="">Select</option>

                                        <?php
                                        if ($rowCount > 0) {

                                            while ($row = $result->fetch_array()) {

                                                echo '<option value="' . $row['wh_id'] . '">' . $row['wh_name'] . '</option>';
                                            }
                                        } else {
                                            echo '<option value="">District not available</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    <div class="row-fluid">
                        <div class="span3">

                            <div class="control-group">
                                <label class="control-label" for="doa">Appointment Start Date</label>
                                <div class="controls"><input class="span12" type="text" id="doa" name="doa" /></div>
                            </div>
                            
                        </div>
                        <div class="span3">
                            <div id="dvposting" style="display: none">

                                <div class="control-group">
                                    <label class="control-label" for="ed">Appointment End Date</label>
                                    <div class="controls"><input class="span12" type="text" id="ed" name="ed" /></div>
                                </div>
                            </div>
                        </div>
                        <div class="span3">
                            <div class="control-group">
                                <label class="control-label" for="apointment_letter">Appointment letter</label>
                                <div class="controls"><input type="file" id="apointment_letter" name="apointment_letter" /></div>
                            </div>
                        </div>
                        
                        <div class="span3">
                            <div class="control-group">
                                <label class="control-label" for="additional_charge">Additional Charge </label>
                                <div class="controls"><input class="span12" id="additional_charge" name="additional_charge" type="text" /></div>
                            </div>
                        </div>
                    </div>
                    <div class="row-fluid">
                        <div class="span3">
                            <div class="control-group">
                                <label class="control-label" for="transfer_status">Transfer Status</label>
                                <div class="controls">
                                    <select class="span12" name="transfer_status" id="transfer_status">
                                        <option value="">Select</option>
                                        <?php
                                        $location = new transfer_status();
                                        $result = $location->transferstatusdropdown();
                                        while ($row = $result->fetch_assoc()) {
                                        ?>
                                            <option value="<?php echo $row['pk_id']; ?>"><?php echo $row['transfer_status']; ?></option>
                                        <?php
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                              <div class="span3">
                         
                            <div class="control-group">
                                <label class="control-label" for="doa">Notification Date </label>
                                <div class="controls"><input class="span12" type="text" id="notification_date" name="notification_date" /></div>
                            </div>
                               
                        </div>
                        
                            <br>
                            <br>
                        <div class="span6 right">
                            <div class="control-group">
                                <!--<label class="control-label" for="postbutton">&nbsp;</label>-->
                                <div class="controls"><button type="button" id="postbutton" class="btn btn-primary">Add</button></div>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" id="pers_post_id" name="pers_post_id" value="" />
                </form>
            </div>
        </div>
        <!-- // Column END -->

        <div class="row-fluid">
            <div class="span12" id="post_data">

            </div>
        </div>


    </div>
</div>
<!-- // Content END -->
<?php include 'template/footer.php'; ?>

<script>
    function duplicate_emp_number(emp)

    {
        $.ajax({
                type: "POST",
                data: {
                    emp: emp
                },
                url: "ajax_duplicate_empnumber.php"
            })
            .success(function(e) {
                if (e == 'true') {
                    alert("employee number already exist");
                }
            });
    }


    $(function() {
        $("#chkposting").click(function() {
            if ($(this).is(":checked")) {
                $("#dvposting").hide();
                $("#ed").val('00/00/0000');
            } else {
                $("#dvposting").show();
            }
        });
    });

    $("#personalbutton").click(function(e) {
        var form = $("#addpersonalform");
        form.validate({
            rules: {
                // simple rule, converted to {required:true}
                name: "required",
                // compound rule
                contact_no: {
                    required: true,
                    number: true
                }
            }
        });

        if (form.valid()) {

            var data = $('#addpersonalform').serialize();
            $.post('add_personal.php', data).done(function(arsalan) {
                $('.widget').find('.widget-body').collapse('toggle');
                $("#personal_id").val(arsalan);
                $("#pers_specility_id").val(arsalan);
                $("#pers_training_id").val(arsalan);
                //            $("#family_children_id").val(arsalan);
                $("#pers_children_id").val(arsalan);
                $("#pers_post_id").val(arsalan);
                $("#pers_spouse_id").val(arsalan);

                document.documentElement.scrollTop = 0;
            });
        } else {
            e.preventDefault();
            alert("Please fill the form");
        }
    });
    
        var max = 11;
        $('#contact_no').keypress(function (e) {
            if (e.which < 0x20) {
                // e.which < 0x20, then it's not a printable character
                // e.which === 0 - Not a character
                return;     // Do nothing
            }
            if (this.value.length == max) {
                e.preventDefault();
            } else if (this.value.length > max) {
                // Maximum exceeded
                this.value = this.value.substring(0, max);
            }
        });
        $("#addpersonalform").validate({
            rules: {
                name: {
                    minlength: 3
                },
                contact_no: {
                    number: true,
                    minlength: 11,
                    maxlength: 11
                },
                cnic: {
                    NICNumber: true,
                    minlength: 15,
                    maxlength: 15
                },
                email: {
                    emailfull: true
                }
                
//                province : {
//                    province: "required needsSelection"
//                }
            },
            ignore: [],
//            ignore: ':hidden:not("#province")', // Tells the validator to check the hidden select
//            ignore : ".ignore, :hidden",
//            errorClass: 'invalid'
        });
        jQuery.validator.addMethod('NICNumber', function (value) { 
                return  /^[0-9]{5}-[0-9]{7}-[0-9]{1}$/.test(value); 
            }, 'Please enter a valid National Identity Card Number.');
        jQuery.validator.addMethod("emailfull", function(value, element) {
            return this.optional(element) || /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i.test(value);
           }, "Please enter valid email address!");
    function myFunction() {
        var x = document.getElementById("myDIV");
        if (x.style.display === "none") {
            x.style.display = "block";
        } else {
            x.style.display = "none";
        }
    }

    $("#educationbutton").click(function() {
        var data = $('#educationform').serialize();
        $.post('add_education.php', data).done(function(data) {
            //$('#educationform').reset();
            //$('.widget.personal').find('.widget-body').collapse('toggle');
            //$('.widget.education').find('.widget-body').collapse('toggle');

            $("#education_data").html(data);
            //document.documentElement.scrollTop = 0;
            deleteeducation();

        });
    });
    $("#spousebutton1").click(function() {
        var data = $('#educationform1').serialize();
        $.post('add_education.php', data).done(function(data) {
            //$('#educationform').reset();
            //$('.widget.personal').find('.widget-body').collapse('toggle');
            //$('.widget.education').find('.widget-body').collapse('toggle');

            $("#education_data").html(data);
            //document.documentElement.scrollTop = 0;
            deletespous();

        });
    });

    function deleteeducation() {
        $("a[id$='-deleducation']").click(function() {
            var value = $(this).attr("id");
            var id = value.replace("-deleducation", "");
            $.ajax({
                type: "POST",
                url: "delete_education.php",
                data: {
                    id: id,
                    personal_id: $("#personal_id").val()
                },
                dataType: 'html',
                success: function(data) {
                    $("#education_data").html(data);
                    deleteeducation();
                }
            });
        });
    }

    $("#specilitybutton").click(function() {
        var data = $('#specilityform').serialize();
        $.post('add_specility.php', data).done(function(data) {
            //$('.widget.personal').find('.widget-body').collapse('toggle');
            //$('.widget.education').find('.widget-body').collapse('toggle');
            $("#specility_data").html(data);
            //document.documentElement.scrollTop = 0;
            deletespeciality();
        });
    });
    function deletespous() {
        $("a[id$='-delspouse']").click(function () {
            var value = $(this).attr("id");
            var id = value.replace("-delspouse", "");
            $.ajax({
                type: "POST",
                url: "delete_spous_pers.php",
                data: {
                    id: id,
                    pers_spouse_id: $("#pers_spouse_id").val()
                },
                dataType: 'html',
                success: function (data) {
                    $("#spouse_data").html(data);
                    deletespous();
                }
            });
        });
    }
    function deletespeciality() {
        $("a[id$='-delspeciality']").click(function() {
            var value = $(this).attr("id");
            var id = value.replace("-delspeciality", "");
            $.ajax({
                type: "POST",
                url: "delete_specialty_pers.php",
                data: {
                    id: id,
                    pers_specility_id: $("#pers_specility_id").val()
                },
                dataType: 'html',
                success: function(data) {
                    $("#specility_data").html(data);
                    deletespeciality();
                }
            });
        });
    }

    $("#trainingbutton").click(function() {
        var data = $('#trainingform').serialize();
        $.post('add_training.php', data).done(function(data) {
            //$('.widget.personal').find('.widget-body').collapse('toggle');
            //$('.widget.education').find('.widget-body').collapse('toggle');
            $("#training_data").html(data);
            //document.documentElement.scrollTop = 0;
            deletetraining();
        });
    });

    function deletetraining() {
        $("a[id$='-deltraining']").click(function() {
            var value = $(this).attr("id");
            var id = value.replace("-deltraining", "");
            $.ajax({
                type: "POST",
                url: "delete_training_pers.php",
                data: {
                    id: id,
                    pers_training_id: $("#pers_training_id").val()
                },
                dataType: 'html',
                success: function(data) {
                    $("#training_data").html(data);
                    deletetraining();
                }
            });
        });
    }

    $("#spousebutton").click(function() {
        var data = $('#spouseform').serialize();
        $.post('add_family.php', data).done(function(data) {
            //$('.widget.personal').find('.widget-body').collapse('toggle');
            //$('.widget.education').find('.widget-body').collapse('toggle');
            //$("#spouse_data").html(data);
            //document.documentElement.scrollTop = 0;
            $("#family_children_id").val(data);
            //$("#spousebutton").html("Saved");
            $("#spouse_data").html(data);
            deletespous();
            //$("#spousebutton").attr("disabled", true);
        });
    });

    $("#childrenbutton").click(function() {
        var family_id = $("#family_children_id").val();
        if (family_id == '') {
            alert("Please update Family record first");
        } else {
            var data = $('#childrenform').serialize();
            $.post('add_children.php', data).done(function(data) {
                //$('.widget.personal').find('.widget-body').collapse('toggle');
                //$('.widget.education').find('.widget-body').collapse('toggle');
                $("#children_data").html(data);
                //document.documentElement.scrollTop = 0;
                deletechildren();
            });
        }
    });

    function deletechildren() {
        $("a[id$='-delchildren']").click(function() {
            var value = $(this).attr("id");
            var id = value.replace("-delchildren", "");
            $.ajax({
                type: "POST",
                url: "delete_children.php",
                data: {
                    id: id,
                    pers_children_id: $("#pers_children_id").val()
                },
                dataType: 'html',
                success: function(data) {
                    $("#children_data").html(data);
                    deletechildren();
                }
            });
        });
    }

    $("#postbutton").click(function() {
        var form = document.getElementById('postform');
        $.ajax({
            type: "POST",
            url: "add_post.php",
            data: new FormData(form),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                $("#post_data").html(data);
                deleteposting();
            }
        });
        //        var data = $('#postform').serialize();
        //        $.post('add_post.php', data).done(function (data) {
        //            //$('.widget.personal').find('.widget-body').collapse('toggle');
        //            //$('.widget.education').find('.widget-body').collapse('toggle');
        //            $("#post_data").html(data);
        //            //document.documentElement.scrollTop = 0;
        //            deleteposting();
        //        });
    });

    function deleteposting() {
        $("a[id$='-delposting']").click(function() {
            var value = $(this).attr("id");
            var id = value.replace("-delposting", "");
            $.ajax({
                type: "POST",
                url: "delete_post_pers.php",
                data: {
                    id: id,
                    pers_post_id: $("#pers_post_id").val()
                },
                dataType: 'html',
                success: function(data) {
                    $("#post_data").html(data);
                    deleteposting();
                }
            });
        });
    }

    $("#is_health_professional").change(function() {
        var value = $(this).val();
        if (value == 'Yes') {
            $("#divfamily_id, #divfamily_id2").show();
            //            $.ajax({
            //                type: "POST",
            //                url: "get-spouse-list.php",
            //                data: {
            //                    gender: $("#gender").val()
            //                },
            //                dataType: 'html',
            //                success: function (data) {
            //                    $('#family_id').html(data);
            //                }
            //            });
        } else {
            $("#divfamily_id, #divfamily_id2").hide();
            $("#spouse_offcie, #spouse_designation").val = '';
        }
    });

    $("#gender").change(function() {
        var value = $(this).val();
        if (value == 'Female') {
            $("#divhusband_id").show();
            $.ajax({
                type: "POST",
                url: "add_personal_record.php",
                data: {
                    gender: $("#gender").val()
                },
                dataType: 'html',
                success: function(data) {
                    $('#husband_id').html(data);
                }
            });
            $("#husband_name").css("display", "block");
        } else {

            $("#husband_name").val("");
            $("#divhusband_id").css("display", "none");
        }
    });
    $("a[id$='-fid']").click(function() {
        var value = $(this).attr("id");
        var id = value.replace("-fid", "");

        $.ajax({
            type: "POST",
            url: "ajax-edit.php",
            data: {
                id: id
            },
            dataType: 'html',
            success: function(data) {
                $('#editdiv').html(data);
                $('#submit').removeAttr("disabled");
                $("#dob,#date_of_appointment").datepicker({
                    dateFormat: 'dd/mm/yy'
                });
            }
        });
    });
    $("#postal_address").keypress(function() {
        var value = $(this).val();
//        if($("#residential_address").val() == '')
//        {
            $("#residential_address").val(value);
//        }
//        if($("#current_address").val() == '')
//        {
            $("#current_address").val(value);
//        }
    });
    $("a[id$='-pid']").click(function() {
        var value = $(this).attr("id");
        var id = value.replace("-pid", "");

        $.ajax({
            type: "POST",
            url: "ajax-upload.php",
            data: {
                id: id
            },
            dataType: 'html',
            success: function(data) {
                $('#uploaddiv').html(data);
                $('#submit').removeAttr("disabled");
            }
        });
    });

    function minmax(value, min, max) {
        if (parseInt(value) < min || isNaN(parseInt(value)))
            return min;
        else if (parseInt(value) > max)
            return max;
        else
            return value;
    }

    function emailIsValid(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
    }

//    function cnicIsValid(cnic) {
//        var isvalid = /\d{5}-\d{7}-\d/.test(cnic);
//        if (isvalid) {
//            //var cnic = $(this).val();
//            //            alert(cnic);
//            $.ajax({
//                    type: "POST",
//                    data: {
//                        nic: cnic
//                    },
//                    url: "ajax_duplicate_cnic.php"
//                })
//                .success(function(e) {
//                    if (e == 'true') {
//                        alert("cnic already exist");
//                    }
//                });
//        } else {
//            return false;
//        }
//        return true;
//
//    }
    //   function register_user()
    //        
    //    {
    //        var cnic = $(this).val();
    //            $.ajax(
    //                {
    //                    type:"POST",
    //                    data:{nic:cnic},
    //                    url:"ajax_duplicate_cnic.php"                    
    //                })
    //            .fail(function()
    //                  {
    //                    $('#user').html("This user already exists");
    //                  }
    //            );                
    //        }

    $("#nationality").dropdown({});

    $("#dob,#date_of_appointment,#date_of_birth,#joining_date,#child_dob,#start_date,#completion_date,#attestation_date, #doa, #ed,#notification_date").datepicker({
        dateFormat: 'dd/mm/yy'
    });
    
    $("a[id$='-did']").click(function() {
        var value = $(this).attr("id");
        var id = value.replace("-did", "");

        $.ajax({
            type: "POST",
            url: "ajax-detail.php",
            data: {
                id: id
            },
            dataType: 'html',
            success: function(data) {
                $('#detaildiv').html(data);
                $('#submit').removeAttr("disabled");
            }
        });
    });
    $("#post_id").click(function() {
        var id = $("#post_id").val();
//        var id = value.replace("-did", "");

        $.ajax({
            type: "POST",
            url: "get_sanction_data.php",
            data: {
                id: id
            },
            dataType: 'json',
            success: function(data) {
                $('#sanc_id').val(data);
//                $('#submit').removeAttr("disabled");
            }
        });
    });
    
     $('#type').change(function() {
//                alert('saad');
                var type = $(this).val();
                $.ajax({
                    type: "POST",
                    url: "ajax_degree_level.php",
                    data: {
                        d_level: type
                    },
                    dataType: 'html',
                    success: function(data) {
//                        alert($('#detaildiv').html(data););
                        $('#degree_level').html(data);
//                        $('#submit').removeAttr("disabled");
                    }
                });
                seltype(type);
            });    
    $('#mod_app').change(function() {
                var type = $(this).val();
                if(type == 'By Deputation')
                {
                    $('#dofficehide').fadeIn();
                }    
                else {
                    $('#dofficehide').fadeOut();
                    $('#sel_office').val('');
                }
        });
    function seltype(type)
        {
            if (type == 1)
                {
                    $('#university_combo').fadeIn();
                    $('#university_combo1').fadeOut();
                    $('#university_combo1').val();
                    $('#university_combo2').fadeOut();
                    $('#university_combo2').val();
                }
                if (type == 2)
                {
                    $('#university_combo').fadeIn();
                    $('#university_combo1').fadeOut();
                    $('#university_combo1').val();
                    $('#university_combo2').fadeOut();
                    $('#university_combo2').val();
                }
               else if (type == 3)
                {
                    $('#university_combo').fadeIn();
                    $('#university_combo1').fadeOut();
                    $('#university_combo1').val();
                    $('#university_combo2').fadeOut();
                    $('#university_combo2').val();
                    
                }
                else if (type == 4)
                {
                    $('#university_combo').fadeOut();
                    $('#university_combo').val();
                    $('#university_combo1').fadeIn();
                    $('#university_combo2').fadeOut();
                    $('#university_combo2').val();
                }
                else if (type == 5)
                {
                    $('#university_combo').fadeOut();
                    $('#university_combo').val();
                    $('#university_combo1').fadeIn();
                    $('#university_combo2').fadeOut();
                    $('#university_combo2').val();
                }
                else if (type == 6)
                {
                    $('#university_combo').fadeOut();
                    $('#university_combo').val();
                    $('#university_combo1').fadeIn();
                    $('#university_combo2').fadeOut();
                    $('#university_combo2').val();
                }
                else if (type == 7)
                {
                    $('#university_combo').fadeOut();
                    $('#university_combo').val();
                    $('#university_combo1').fadeOut();
                    $('#university_combo1').val();
                    $('#university_combo2').fadeIn();
                }
        }
        
        $(document).ready(function(){
            $('#removepostlimit').click(function(){
                 var removepostlimit_id = 0;

                if ($('#removepostlimit').is(":checked")) {
                     var removepostlimit_id = 1;
//                      alert(removepostlimit_id);
                }

                 var id = $(this).val();
                 $.ajax({
                      url:"removepostlimit.php",
                      method:"POST",
                      data:{removepostlimit_id:removepostlimit_id,id:id},
                      success: function(data){
//                         alert(data);
                     },
                });

            });
         });
        
        $('#district_of_domicile').select2();
        $('#actual_desg').select2();
        $('#residential_city').select2();
        $('#current_city').select2();
        $('#post_id').select2();
        $('#post_place_id').select2();
        $('#sancpost').select2();
</script>
</body>

</html>