<?php
require_once 'classes/sanctioned_desg.php';
require_once 'classes/datetime.php';

$sanctioned_desg = new sanctioned_desg();
$file_id = $_POST['id'];
$file = $sanctioned_desg->find_by_id($file_id);
$data = $file->fetch_array();

?>
<!-- Row -->
<div class="row-fluid">

    <!-- Column -->
    <div class="span12">

        <!-- Group -->
        <div class="control-group">
            <label class="control-label" for="sanctioned_desg">Sanctioned_Designation</label>
            <div class="controls"><input class="span12" id="sanctioned_desg" name="sanctioned_desg" type="text" value="<?php echo $data['sanctioned_desg']; ?>" /></div>
        </div>  
        <div class="control-group">
            <label class="control-label" for="bps1">BPS</label>
            <div class="controls"><input class="span12" id="bps" name="bps" type="text" onkeyup="this.value = minmax(this.value, 1, 22)" /></div>
        </div>
        <div class="control-group">
            <label class="control-label" for="direct">By Direct</label>
            <div class="controls"><input class="span12" placeholder="%" min="0" max="100" id="direct" name="direct" value="<?php echo $data['direct']; ?>" type="number" /></div>
        </div>  
        <div class="control-group">
            <label class="control-label" for="promotion">By Promotion</label>
            <div class="controls"><input class="span12" id="promotion" min="0" max="" placeholder="%" name="promotion" value="<?php echo $data['promotion']; ?>" type="number" /></div>
        </div>  
    </div>
    <!-- // Column END -->



</div>

<input type="hidden" name="fileid" value="<?php echo $file_id; ?>"/>

<script>
    $(document).ready(function() {
            $('#direct').keyup(function() {
                var dInput = 100-($(this).val());
        //        if(dInput < 100)
        //        {
        //            var res = 100-dInput;
        //        }
                $('#promotion').attr('max', dInput);
        //        $('#promotion').data('max',res);
            });
        });
</script>