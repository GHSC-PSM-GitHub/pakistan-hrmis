<?php

session_start();
require_once 'classes/roles.php';
require_once 'classes/datetime.php';

$role = new role();

if (isset($_REQUEST['roleid']) && !empty($_REQUEST['roleid'])) {
    $role->pk_id = $_REQUEST['roleid'];
}

$role->role_name = $_POST['role_name'];

$role->is_active = 1;


$file = $role->save();

if ($file) {
    header("location: roles.php");
} else {
    header("location: roles.php");
}