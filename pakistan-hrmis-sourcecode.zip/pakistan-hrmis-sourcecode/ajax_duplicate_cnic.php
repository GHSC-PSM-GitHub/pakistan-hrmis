<?php

require_once 'classes/database.php';
require_once 'classes/personal.php';

$cnic = $_POST['nic'];
$personal = new personal();
$query = $personal->find_by_cnic($cnic);
if (!empty($query)) {
    echo 'true';
} else {
    echo 'false';
}
?>