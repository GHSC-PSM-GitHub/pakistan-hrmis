<?php

session_start();
require_once 'classes/category.php';
require_once 'classes/datetime.php';

$category = new category();

if (isset($_REQUEST['categoryid']) && !empty($_REQUEST['categoryid'])) {
    $category->pk_id = $_REQUEST['categoryid'];
}

$category->category_value = $_POST['category_value'];

$category->is_active = 1;


$file = $category->save();

if ($file) {
    header("location: category.php");
} else {
    header("location: category.php");
}