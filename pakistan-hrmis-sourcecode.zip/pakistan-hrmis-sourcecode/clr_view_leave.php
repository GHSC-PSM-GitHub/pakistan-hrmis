#####################
Batch Text Replacer Demo ID:4932614385
#####################
<?php

/**
 * clr_view
 * @package im
 * 

 * 
 * @version    2.2
 * 
 */

include("template/header.php");
require_once 'classes/transfer_request_form.php';

$education = new transfer_management();

$leave_id = $_GET['id'];
//$result = $education->find_by_personal($posting_form_id);
 $qry_mw = "SELECT
	leave_record.pk_id,
	leave_record.comm_date,
	leave_record.no_of_days,
	tbl_warehouse.wh_name,
	designation.designation,
	users.username,
	leave_record.notification_date,
	leave_record.cc,
	leave_record.notification_no,
	leave_types.leave_type,
	tbl_locations.LocName 
FROM
	leave_record
	INNER JOIN tbl_warehouse ON leave_record.curr_station = tbl_warehouse.wh_id
	INNER JOIN designation ON leave_record.designation = designation.id
	INNER JOIN users ON leave_record.user_id = users.pk_id
	INNER JOIN leave_types ON leave_record.leave_nature = leave_types.pk_id
	INNER JOIN tbl_locations ON leave_record.curr_district = tbl_locations.PkLocID 
WHERE
	leave_record.pk_id = '$leave_id'";
//echo $qry_mw; exit;
                    $qry1 = mysqli_query($conn, $qry_mw);
                    while ($result1 = mysqli_fetch_assoc($qry1)) {
//                        print_r($result1); exit;
                        $username = $result1['username'];
//                       $order_date = $result1['current_date'];
                        $notification_no = $result1['notification_no'];
                        $notification_date = $result1['notification_date'];
                        $leave_type = $result1['leave_type'];
                        $district = $result1['LocName'];
                        $comm_date = $result1['comm_date'];
                        $no_of_days = $result1['no_of_days'];
                        $designation = $result1['designation'];
                        $wh_name = $result1['wh_name'];
                        $cc = $result1['cc'];
                    }
                    $notification_date = strtotime($notification_date);
                    $notification_date = date('d-M-Y', $notification_date);
                    $comm_date = strtotime($comm_date);
                    $comm_date = date('d-m-Y',$comm_date);
                    

?>

</head>
<!-- END HEAD -->

<body class="page-header-fixed page-quick-sidebar-over-content">
    <!-- BEGIN HEADER -->
    <div class="page-container">
        <div class="page-content-wrapper">
            <div class="page-content">

                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-10">
                        <div class="widget">

                            <div class="widget-body">
                                <div id="printing" style="clear:both;margin-top:20px;">
                                    <div style="margin-left:25px !important; width:90% !important;">
                                        <style>
                                            body {
                                                margin: 0px !important;
                                                font-family: Arial, Helvetica, sans-serif;
                                            }

                                            table#myTable {
                                                margin-top: 20px;
                                                border-collapse: collapse;
                                                border-spacing: 0;
                                            }

                                            table#myTable tr td,
                                            table#myTable tr th {
                                                font-size: 11px;
                                                padding-left: 5px;
                                                text-align: left;
                                                border: 1px solid #999;
                                            }

                                            table#myTable tr td.TAR {
                                                text-align: right;
                                                padding: 5px;
                                                width: 50px !important;
                                            }

                                            .sb1NormalFont {
                                                color: #444444;
                                                font-family: Verdana, Arial, Helvetica, sans-serif;
                                                font-size: 11px;
                                                font-weight: bold;
                                                text-decoration: none;
                                            }

                                            p {
                                                margin-bottom: 5px;
                                                font-size: 11px !important;
                                                line-height: 1 !important;
                                                padding: 0 !important;
                                            }

                                            table#headerTable tr td {
                                                font-size: 11px;
                                            }

                                            /* Print styles */
                                            @media only print {

                                                table#myTable tr td,
                                                table#myTable tr th {
                                                    font-size: 8px;
                                                    padding-left: 2 !important;
                                                    text-align: left;
                                                    border: 1px solid #999;
                                                }

                                                #doNotPrint {
                                                    display: none !important;
                                                }
                                            }
                                        </style>

                                        <center>
                                            <table>
                                                <tr style="background-color:white">
                                                    <th><img src="common/theme/images/kp.png" style="width:80px" style="display:inline-block; " /></th>
                                                    <th style="float:right"></th>
                                                    <th>
                                                        <p style="color: #000000; font-size: 30px;text-align:center">
                                                            <span style="float:left; font-weight:normal;"><i style="color:black !important" onClick="history.go(-1)" class="fa fa-arrow-left" /></i></span>
                                                            <span style="font-weight:bold; text-decoration: underline; font-size: 1.4em ">GOVERNMENT OF KHYBER PAKHTUNKHWA<br>HEALTH DEPARTMENT</span>
                                                        </p>
                                                    </th>
                                                </tr>
                                            </table>
                                        </center>

                                        <br />
                                        <br />
                                        <h5 class="center">Dated Peshawar, the <?php echo $notification_date; ?></h5>
                                        <br />
                                        <br />
                                        <h5 class="left" ><u>Notification</u></h5>
                                         <span style=" float:left;font-weight:bold; text-decoration: underline; font-size: 1em "><u><?php echo $notification_no; ?></u>:-</span>&nbsp;&nbsp;<span style="font-size:1em">Sanction is hereby accorded to the grant of <?php echo $no_of_days .'-days '. $leave_type; ?> in respect of Dr. <?php echo $username.' '. $designation; ?> attached to <?php echo $wh_name.' District '. $district .' w.e.f '.  $comm_date; ?> from the date of availing (but not more than (<?php echo $no_of_days; ?>) days from the issuance of this notification.</span>
                                       <!--<div class="row"><div class="col-md-2"></div><div class="col-md-10">jcsklcklhclshclhslchlshsh</div></div>-->


                                        <p style="text-align:center;margin-right:35px;">
                                            <?php // echo "For $mainStk District $distName"; 
                                            ?>
                                        </p>
                                 
                                        <div style="clear:both;"></div>
                                     
                                         <span class="pull-right" style="float:right; font-weight: bold; font-size: 1.0em">&nbsp;&nbsp;SECRETARY HEALTH <br />KHYBER PAKHTUNKHWA</span>
                                       <br />
                                        <br />
                                        <br />
                                        <br />
                                        <!--<span style="font-weight:bold; text-decoration: underline; font-size: 1.1em; float:left ">Endst.of even No. &DATE</span>&nbsp;&nbsp;<span style="font-size:1em"></span>-->
                                        <p style="float:left; width:100%"><b><u>ENDST NO AND DATE EVEN:</u></b></p>
                                        <p style="float:left; width:100%"><b>Copy forwarded to:</b></p>
                                        <p style="float:left; width:100%">
                                            <?php
                                            echo nl2br($cc);
                                            //foreach($abc as $a) { 
                                            ?>
                                            <!--<b><p>1. Accountant Gneral Khyber Pakhtunkhwa Peshawar</p></b>-->
                                            <?php //} 
                                            ?>
                                        </p>
                                         <span class="pull-right" style="float:right; font-weight: bold; font-size: 0.9em">&nbsp;&nbsp;<?php echo $_SESSION['username'];?> <br />Section Officer (E-I)</span>
                                        <table width="100%">
                                            <!--                                            <tr>
                                                <td colspan="4">&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td colspan="4">&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="text-align:right;" width="10%" class="sb1NormalFont">Name:</td>
                                                <td width="40%">__________________________</td>
                                                <td width="30%" style="text-align:right;" class="sb1NormalFont">Signature:</td>
                                                <td width="20%">__________________________</td>
                                            </tr>
                                            <tr>
                                                <td colspan="4">&nbsp;</td>
                                            </tr>-->
                                            <!--                                            <tr>
                                                <td style="text-align:right;" class="sb1NormalFont">Designation:</td>
                                                <td>__________________________</td>
                                                <td style="text-align:right;" class="sb1NormalFont">Date:</td>
                                                <td>__________________________</td>
                                            </tr>-->
                                            <tr id="doNotPrint">
                                                <td colspan="4" style="text-align:right; border:none; padding-top:15px;">
                                                    <input type="button" onClick="history.go(-1)" value="Back" class="btn btn-primary" />
                                                    <input type="button" onClick="window.print()" value="Print" class="btn btn-warning" />
                                                </td>
                                            </tr>
                                        </table>

                                        <!--<div id="watermark" style="font-size:200px;font-color:#eeeee; opacity: 0.2;z-index: 5;right:50%;left:30%;top: 60%;position: absolute;display: block;   -ms-transform: rotate(340deg);  -webkit-transform: rotate(340deg);  transform: rotate(340deg);">Draft</div>-->

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END FOOTER -->

    <!-- END JAVASCRIPTS -->
</body>
<!-- END BODY -->

</html>
<?php
include("template/footer.php");

#####################
Batch Text Replacer Demo ID:415164
#####################
