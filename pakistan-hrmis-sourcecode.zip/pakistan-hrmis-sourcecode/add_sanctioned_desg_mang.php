<?php

session_start();
require_once 'classes/sanctioned_desg.php';

require_once 'classes/datetime.php';

$sanctioned_desg = new sanctioned_desg();
//$file = $speciality->save();

if(isset($_REQUEST['fileid']) && !empty($_REQUEST['fileid'])){
    $sanctioned_desg->pk_id = $_REQUEST['fileid'];
}
$sanctioned_desg->sanctioned_desg = $_POST['sanctioned_desg'];
$sanctioned_desg->is_active = 1;
$sanctioned_desg->bps = $_POST['bps'];
$sanctioned_desg->direct = !empty($_POST['direct']) ? $_POST['direct'] : (100-$_POST['promotion']);
$sanctioned_desg->promotion = !empty($_POST['promotion']) ? $_POST['promotion'] : (100-$_POST['direct']);

$file = $sanctioned_desg->save();

if ($file) {
    header("location: sanctioned_designations.php");
} else {
    header("location: sanctioned_designations.php");
}