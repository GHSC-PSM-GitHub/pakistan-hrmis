<?php
require_once 'classes/education.php';
require_once 'classes/university.php';
require_once 'classes/posting.php';
require_once 'classes/datetime.php';
require_once 'classes/locations.php';
require_once 'classes/post.php';
require_once 'classes/warehouse.php';
require_once 'classes/degree.php';

$postingone = new education();
$posting_place_id = $_POST['id'];
$file = $postingone->find_by_id($posting_place_id);
$data = $file->fetch_array();

?>
<style>
/*    @media (prefers-reduced-motion: reduce) {
    .fade {
        transition: none;
    }
}*/
    </style>
<!-- Row -->
<div class="row-fluid">

    <!-- Column -->
    <div class="span12">

        <!-- Group -->
                             
                            <div class="control-group">
                                <label class="control-label" for="typee">Select Level</label>
                                <div class="controls">
                                    <select class="span12" name="typee" id="typee">
                                        <option value="">Select</option>
                                        <option value="1">Primary</option>
                                        <option value="2">Middle</option>
                                        <option value="3">SSC / (O/A Levels)</option>
                                        <option value="4">HSSC / DAE</option>
                                        <option value="5">Bachelor's Degree</option>
                                        <option value="6">Master's Degree</option>
                                        <option value="7">Phd</option>
                                    </select>
                                </div>
                            </div>
                       <!-- Column -->
                        
                        <div class="control-group" id="university_comboo" style="display: none">

                            <!-- Group -->
                            <?php
                            $list = new university();
                            $result = $list->universitydropdown();

                            $rowCount = $result->num_rows;
                            ?>
                                <label class="control-label" for="university_id">School Name</label>
                                <!--<div class="controls"><input class="span12" id="university_id" name="university_id" type="text" /></div>-->
                                <div class="controls">
                                    <select class="span12" name="university_id" id="university_id">
                                        <option value="">Select</option>

                                        <?php
                                        if ($rowCount > 0) {

                                            while ($row = $result->fetch_array()) {
                                                if($data['university_id'] == $row['pk_id']) { $sel = "selected=selected";  }
                                                echo '<option value="' . $row['pk_id'] . '" "'.$sel.'">' . $row['university_name'] . '</option>';
                                            }
                                        } else {
                                            echo '<option value="">University not available</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                        </div>
                        <div class="control-group" id="university_combo11" style="display: none">
                            <!-- Group -->
                            <?php
                            $list = new university();
                            $result = $list->universitydropdown();

                            $rowCount = $result->num_rows;
                            ?>
                                <label class="control-label" for="university_id">College / University Name</label>
                                <!--<div class="controls"><input class="span12" id="university_id" name="university_id1" type="text" /></div>-->
                                <div class="controls">
                                    <select class="span12" name="university_id1" id="university_id">
                                        <option value="">Select</option>

                                        <?php
                                        if ($rowCount > 0) {

                                            while ($row = $result->fetch_array()) {
                                                if($data['university_id'] == $row['pk_id']) { $sel = "selected=selected";  }
                                                echo '<option value="' . $row['pk_id'] . '" "'.$sel.'">' . $row['university_name'] . '</option>';
                                            }
                                        } else {
                                            echo '<option value="">University not available</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                        </div>
                        <div class="control-group" id="university_combo22" style="display: none">
                            <!-- Group -->
                            <?php
                            $list = new university();
                            $result = $list->universitydropdown();

                            $rowCount = $result->num_rows;
                            ?>
                             <label class="control-label" for="university_id">University Name</label>
                             <!--<div class="controls"><input class="span12" id="university_id" name="university_id2" type="text" /></div>-->
                            <div class="controls">
                             <select class="span12" name="university_id2" id="university_id">
                                    <option value="">Select</option>
                                    
                                    <?php
                                    if ($rowCount > 0) {

                                        while ($row = $result->fetch_array()) {
                                            if($data['university_id'] == $row['pk_id']) { $sel = "selected=selected";  }
                                            echo '<option value="' . $row['pk_id'] . '" "'.$sel.'">' . $row['university_name'] . '</option>';
                                        }
                                    } else {
                                        echo '<option value="">University not available</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="control-group" id="degree_levell">

                            
                        </div>
<!--                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="start_date">Start Date </label>
                                <div class="controls"><input class="span12" id="start_date" name="start_date" type="text" /></div>
                            </div>
                        </div>
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="completion_date">Completion Date </label>
                                <div class="controls"><input class="span12" id="completion_date" name="completion_date" type="text" /></div>
                            </div>
                        </div>-->
                            <div class="control-group">
                                <label class="control-label" for="e_month">Ending Month</label>
                                <div class="controls">
                                    <select class="span12" id="e_month" name="e_month" >
                                        <?php for ($m = 1; $m <= 12; $m++) {
                                            $sel = "";
                                            if ($m == $data['e_month']) {
                                                $sel = "selected=selected";
                                            }
                                        ?>
                                            <option value="<?php echo $m; ?>" <?php echo $sel; ?>><?php echo date('F', mktime(0, 0, 0, $m, 10)); ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <!--<div class="controls"><input class="span12" id="percentage" name="percentage" type="text" /></div>-->
                            </div>
                            <div class="control-group">
                                <label class="control-label" for="e_year">Ending Year</label>
                                <!--<div class="controls"><input class="span12" id="percentage" name="percentage" type="text" /></div>-->
                                <div class="controls">
                                    <select class="span12" id="e_year" name="e_year" >
                                        <?php for ($y = 1950; $y <= date("Y"); $y++) {
                                            $sel = "";
                                            if ($y == $data['e_year']) {
                                                $sel = "selected=selected";
                                            }
                                        ?>
                                            <option value="<?php echo $y; ?>" <?php echo $sel; ?>><?php echo $y; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label" for="e_gpa">Total GPA</label>
                                <div class="controls"><input class="span12" id="e_gpa" name="e_gpa" value="<?php echo $data['e_gpa']; ?>" type="text" /></div>
                            </div>

                            <div class="control-group">
                                <label class="control-label" for="e_gpa">Obtained GPA</label>
                                <div class="controls"><input class="span12" id="obtain_gpa" name="obtain_gpa" value="<?php echo $data['obtained_gpa']; ?>" type="text" /></div>
                            </div>
                            <div class="control-group">
                                <label class="control-label" for="total_marks">Total Marks</label>
                                <div class="controls"><input class="span12" id="total_marks" name="total_marks" value="<?php echo $data['total_marks']; ?>" type="text" /></div>
                            </div>
                            <div class="control-group">
                                <label class="control-label" for="total_marks">Obtained Marks</label>
                                <div class="controls"><input class="span12" id="obtain_marks" name="obtain_marks" value="<?php echo $data['obtained_marks']; ?>" type="text" /></div>
                            </div>
<!--                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="cgpa">Cgpa</label>
                                <div class="controls"><input class="span12" id="cgpa" name="cgpa" type="text" /></div>
                            </div>
                        </div>
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="hec_attestation_no">Hec Attestation No</label>
                                <div class="controls"><input class="span12" id="hec_attestation_no" name="hec_attestation_no" type="text" /></div>
                            </div>
                        </div>
                        <div class="span4">
                            <div class="control-group">
                                <label class="control-label" for="attestation_date">Attestation Date</label>
                                <div class="controls"><input class="span12" id="attestation_date" name="attestation_date" type="text" /></div>
                            </div>
                        </div>-->
                            <div class="control-group">
                                <label class="control-label" for="percentage">Percentage</label>
                                <div class="controls"><input class="span12" id="percentage" name="percentage" value="<?php echo $data['percentage']; ?>" type="text" /></div>
                            </div>
       
    </div>
    <!-- // Column END -->

</div>

  <input type="hidden" id="pers_id" name="pers_id" value="<?=$_REQUEST['pers_id']?>"/>

  <input type="hidden" id="pers_post_id" name="pers_post_id" value="<?=$_REQUEST['personal_id']?>"/>

  <input type="hidden" name="postingplaceid"  id="postingplaceid" value="<?php echo $posting_place_id; ?>"/>


<script>
    
//      $("a[id$='-zzid']").click(function () {
//        var value = $(this).attr("id");
//         var pers = $("#pers_post_id").val();
//        var id = value.replace("-zzid", "");
//
//        $.ajax({
//            type: "POST",
//            url: "ajax-edit-posting-place-two.php",
//            data: {
//                id: id,
//                personal_id  : pers
//            },
//            dataType: 'html',
//            success: function (data) {
//                $('#editdiv').html(data);
//                $('#submit').removeAttr("disabled");
//                $("#doa2,#ed2").datepicker({dateFormat: 'dd/mm/yy'});
//            }
//        });
//    });
    
    
         $("#doa3,#ed3").datepicker({dateFormat: 'dd/mm/yy'});

    
    
//    $("#personalbutton").click(function (e) {
//        var form = $("#addpersonalform");
//        form.validate({
//            rules: {
//                // simple rule, converted to {required:true}
//                name: "required",
//                // compound rule
//                contact_no: {
//                    required: true,
//                    number: true
//                }
//            }
//        });
//
//        if (form.valid()) {
//
//            var data = $('#addpersonalform').serialize();
//            $.post('add_personal.php', data).done(function (arsalan) {
//                $('.widget').find('.widget-body').collapse('toggle');
//                $("#personal_id").val(arsalan);
//                $("#pers_specility_id").val(arsalan);
//                $("#pers_training_id").val(arsalan);
////            $("#family_children_id").val(arsalan);
//                $("#pers_post_id").val(arsalan);
//                $("#pers_spouse_id").val(arsalan);
//
//                document.documentElement.scrollTop = 0;
//            });
//        } else {
//            e.preventDefault();
//            alert("Please fill the form");
//        }
//    });
    $("body").on('change','#typee',function(e) {
//    $('#type').on('change', function() {
//    $('#type').click(function() {
//                alert('saad');
                var type = $(this).val();
                $.ajax({
                    type: "POST",
                    url: "ajax_education_degree_lvl.php",
                    data: {
                        d_level: type
                    },
                    dataType: 'html',
                    success: function(data) {
//                        alert(data);
//                        alert($('#detaildiv').html(data););
                        $('#degree_levell').html(data);
//                        $('#submit').removeAttr("disabled");
                    }
                });
                seltype(type);
            });
    
    function seltype(type)
        {
//            alert('saad');
            if (type == 1)
                {
                    $('#university_comboo').fadeIn();
                    $('#university_combo11').fadeOut();
                    $('#university_combo11').val();
                    $('#university_combo22').fadeOut();
                    $('#university_combo22').val();
                }
                if (type == 2)
                {
                    $('#university_comboo').fadeIn();
                    $('#university_combo11').fadeOut();
                    $('#university_combo11').val();
                    $('#university_combo22').fadeOut();
                    $('#university_combo22').val();
                }
               else if (type == 3)
                {
                    $('#university_comboo').fadeIn();
                    $('#university_combo11').fadeOut();
                    $('#university_combo11').val();
                    $('#university_combo22').fadeOut();
                    $('#university_combo22').val();
                    
                }
                else if (type == 4)
                {
                    $('#university_comboo').fadeOut();
                    $('#university_comboo').val();
                    $('#university_combo11').fadeIn();
                    $('#university_combo22').fadeOut();
                    $('#university_combo22').val();
                }
                else if (type == 5)
                {
                    $('#university_comboo').fadeOut();
                    $('#university_comboo').val();
                    $('#university_combo11').fadeIn();
                    $('#university_combo22').fadeOut();
                    $('#university_combo22').val();
                }
                else if (type == 6)
                {
                    $('#university_comboo').fadeOut();
                    $('#university_comboo').val();
                    $('#university_combo11').fadeIn();
                    $('#university_combo22').fadeOut();
                    $('#university_combo22').val();
                }
                else if (type == 7)
                {
                    $('#university_comboo').fadeOut();
                    $('#university_comboo').val();
                    $('#university_combo11').fadeOut();
                    $('#university_combo11').val();
                    $('#university_combo22').fadeIn();
                }
        }
</script>