<?php

session_start();
require_once 'classes/leaves.php';
require_once 'classes/datetime.php';

$post = new leaves();


$uploading = false;

if (isset($_FILES['apointment_letter'])) {
    $uploading = true;
    $_SESSION['msg'] = '';
    $file_name = $_FILES['apointment_letter']['name'];
    $file_size = $_FILES['apointment_letter']['size'];
    $file_tmp = $_FILES['apointment_letter']['tmp_name'];
    $file_type = $_FILES['apointment_letter']['type'];
    if(!empty($_FILES['apointment_letter']['name'])){
        $file_ext = strtolower((explode('.', $_FILES['apointment_letter']['name'])[1]));
    }    

    $extensions = array("jpeg", "jpg", "png", "pdf", "docx", "doc");

//    if (in_array($file_ext, $extensions) === false) {
//        $_SESSION['msg'] = "Error! extension not allowed, please choose an image, pdf or doc file";
//    }

    if ($file_size > 5097152) {
        $_SESSION['msg'] = 'Error! File size must be exactly 5 MB';
    }

    if (empty($_SESSION['msg']) == true) {
        move_uploaded_file($file_tmp, "upload/" . $file_name);
    }
}

if(isset($_REQUEST['fileid']) && !empty($_REQUEST['fileid'])){
    $post->pk_id = $_REQUEST['fileid'];
}

$post->employee_id = $_POST['employee'];
$post->leave_type = $_POST['kind_of_leave'];
$post->approved_by = $_POST['approved_by'];
$post->approved_date = $dt->dbformat($_POST['approved_date']);
$post->from_date = $dt->dbformat($_POST['from_date']);
$post->to_date = $dt->dbformat($_POST['to_date']);
$post->created_by = $_SESSION['userid'];
$post->is_active = 1;
$post->file = $file_name;
//print_r($_SESSION);
//exit;

$file = $post->save();

if ($file) {
    header("location: leave_mgmt.php");
} else {
    header("location: leave_mgmt.php");
}