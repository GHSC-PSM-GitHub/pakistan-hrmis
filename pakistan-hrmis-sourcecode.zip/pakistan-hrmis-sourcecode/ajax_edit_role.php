<?php
require_once 'classes/roles.php';
require_once 'classes/datetime.php';

$reward = new roles();
$file_id = $_POST['id'];
$file = $reward->find_by_id($file_id);
$data = $file->fetch_array();

?>
<!-- Row -->
<div class="row-fluid">

    <!-- Column -->
    <div class="span12">

        <!-- Group -->
        <!-- Group -->
            <div class="control-group">
                <label class="control-label" for="employee_id">Role Name</label>
                <div class="controls"><input class="span12" id="role_name" name="role_name" type="text" value="<?php echo $data['role_name']; ?>" required="" /></div>
            </div>
    </div>
    <!-- // Column END -->



</div>

<input type="hidden" name="fileid" value="<?php echo $file_id; ?>"/>