<?php

require_once 'classes/cadre.php';
require_once 'classes/datetime.php';

$cadre = new cadre();
$cadre_id = $_POST['id'];
$file = $cadre->find_by_id($cadre_id);
$data = $file->fetch_array();

?>
<!-- Row -->
<div class="row-fluid">

    <!-- Column -->
    <div class="span12">

        <!-- Group -->                     
        <div class="control-group">
            <label class="control-label" for="cadre_value">Cadre Value</label>
            <div class="controls"><input class="span12" id="cadre_value" name="cadre_value" type="text" value="<?php echo $data['cadre_value']; ?>" /></div>
        </div>                         
    </div>
    <!-- // Column END -->



</div>

<input type="hidden" name="cadreid" value="<?php echo $cadre_id; ?>"/>