<?php
include "function.php";

$cnic = $_POST['search_by_cnic'];
$empnumber = $_POST['search_by_employeenumber'];
$searchname = substr($_POST['search_by_name'], 0, strpos($_POST['search_by_name'], ','));
$district_of_domicile = $_POST['district_of_domicile'];
$current_city = $_POST['current_city'];
$bps = $_POST['bps'];
$district = $_POST['district'];
show_info($cnic, $empnumber, $searchname,$bps,$district);
?>