<?php

session_start();
require_once 'classes/inactive_reason.php';
require_once 'classes/datetime.php';

$inactive_reason = new inactive_reason();

if (isset($_REQUEST['inactive_reasonid']) && !empty($_REQUEST['inactive_reasonid'])) {
    $inactive_reason->pk_id = $_REQUEST['inactive_reasonid'];
}

$inactive_reason->inactive_value = $_POST['inactive_value'];

$inactive_reason->is_active = 1;


$file = $inactive_reason->save();

if ($file) {
    header("location: inactive_reason.php");
} else {
    header("location: inactive_reason.php");
}