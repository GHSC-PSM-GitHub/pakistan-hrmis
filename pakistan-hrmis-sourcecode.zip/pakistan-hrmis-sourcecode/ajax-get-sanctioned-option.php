<?php
require_once 'classes/post.php';
require_once 'classes/sanctioned_desg.php';
require_once 'classes/datetime.php';

$list = new post();
$result = $list->sancpostdropdown();
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}
echo json_encode($data);
?>