<?php
require_once 'classes/mode_of_appointment.php';
require_once 'classes/datetime.php';

$appointment = new appointment();
$file_id = $_POST['id'];
$file = $appointment->find_by_id($file_id);
$data = $file->fetch_array();

?>
<!-- Row -->
<div class="row-fluid">

    <!-- Column -->
    <div class="span12">

        <!-- Group -->
        <div class="control-group">
            <label class="control-label" for="appointment_type">Appointment Type</label>
            <div class="controls"><input class="span12" id="appointment_type" name="appointment_type" type="text" value="<?php echo $data['appointment_type']; ?>" /></div>
        </div>                        
      
    </div>
    <!-- // Column END -->



</div>

<input type="hidden" name="fileid" value="<?php echo $file_id; ?>"/>