<?php
/*$hostname = "202.83.174.107";
$username = "hrbeta4us";
$password = "s#tUgY1NBWN1";
$db = 'hrkp';*/

$hostname = "localhost";
$username = "root";
$password = "";
//$db = 'hrmisv2';
$db = 'hrdoh';
$conn = mysqli_connect($hostname, $username, $password, $db);
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}

?>