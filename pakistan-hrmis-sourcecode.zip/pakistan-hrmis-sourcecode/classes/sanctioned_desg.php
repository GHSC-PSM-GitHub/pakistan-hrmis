#####################
Batch Text Replacer Demo ID:860980
#####################
<?php

require_once 'database.php';

/**
 * clsStockMaster
 * @package classes
 * 

 * 
 * @version    2.2
 * 
 */
// If it's going to need the database, then it's
// probably smart to require it before we start.
class sanctioned_desg {

    // table name
    protected static $table_name = "sanctioned_desg_record";
    // db connection
    private $conn;
    //db fileds
    protected static $db_fields = array('sanctioned_desg','is_active','bps','direct','promotion');
    public $pk_id;
    public $sanctioned_desg;
    public $is_active;
    public $bps;
    public $direct;
    public $promotion;

   
    public function __construct() {
        $this->conn = new database();
    }

    /**
     * 
     * find_all
     * @return type
     * 
     * 
     */
    public function find_all() {
        if ($_SESSION['role'] == 1) {
            return $this->conn->query("SELECT * FROM " . static::$table_name. " where is_active = 1 ORDER BY sanctioned_desg");
            
             return $this->conn->query($strSql);
        } else {
            return $this->conn->query("SELECT * FROM " . static::$table_name. " where is_active = 1 ORDER BY sanctioned_desg");
            
             return $this->conn->query($strSql);
        }
    }
    
       public function leave_info() {
         if($_SESSION['role'] == 7){
               $where = "WHERE leave_record.`status` = '1' ";     
           }
           elseif($_SESSION['role'] == 8){
               $where = "WHERE leave_record.`status` = '3' ";     
           }
            elseif($_SESSION['role'] == 9){
               $where = "WHERE leave_record.`status` = '5' ";     
           }
           elseif($_SESSION['role'] == 10){
               $where = "WHERE leave_record.`status` = '7' ";     
           }
           else{
               $where = " ";     
           }
            return $this->conn->query("SELECT
	leave_record.pk_id,
	tbl_warehouse.wh_name,
	tbl_locations.LocName,
	designation.designation,
	leave_types.leave_type,
	users.username AS `name`,
	leave_record.bps,
	leave_record.comm_date,
	leave_record.no_of_days,
	app_status.action AS `status` 
FROM
	leave_record
	INNER JOIN tbl_locations ON leave_record.curr_district = tbl_locations.PkLocID
	INNER JOIN tbl_warehouse ON leave_record.curr_station = tbl_warehouse.wh_id
	INNER JOIN designation ON leave_record.designation = designation.id
	INNER JOIN leave_types ON leave_record.leave_nature = leave_types.pk_id
	INNER JOIN users ON leave_record.user_id = users.pk_id
	INNER JOIN app_status ON leave_record.`status` = app_status.pk_id $where");
            
             return $this->conn->query($strSql);

    }
     public function leave_approved() {
             if($_SESSION['role'] == 7){
               $where = "WHERE leave_record.`status` > '2' ";     
           }
           elseif($_SESSION['role'] == 8){
               $where = "WHERE leave_record.`status` > '4' ";     
           }
            elseif($_SESSION['role'] == 9){
               $where = "WHERE leave_record.`status` > '6' ";     
           }
           elseif($_SESSION['role'] == 10){
               $where = "WHERE leave_record.`status` > '8' ";     
           }
           else{
               $where = " ";     
           }
            return $this->conn->query("SELECT
                leave_record.pk_id,
	tbl_warehouse.wh_name, 
	tbl_locations.LocName, 
	designation.designation, 
	leave_types.leave_type, 
	users.username AS name, 
	leave_record.bps, 
	leave_record.comm_date, 
	leave_record.no_of_days
FROM
	leave_record
	INNER JOIN
	tbl_locations
	ON 
		leave_record.curr_district = tbl_locations.PkLocID
	INNER JOIN
	tbl_warehouse
	ON 
		leave_record.curr_station = tbl_warehouse.wh_id
	INNER JOIN
	designation
	ON 
		leave_record.designation = designation.id
	INNER JOIN
	leave_types
	ON 
		leave_record.leave_nature = leave_types.pk_id
	INNER JOIN
	users
	ON 
		leave_record.user_id = users.pk_id $where");
            
             return $this->conn->query($strSql);

    }
     public function leave_rejected() {
         if($_SESSION['role'] == 7){
               $where = "WHERE leave_record.`status` = '2' ";     
           }
           elseif($_SESSION['role'] == 8){
               $where = "WHERE leave_record.`status` = '4' ";     
           }
            elseif($_SESSION['role'] == 9){
               $where = "WHERE leave_record.`status` = '6' ";     
           }
           elseif($_SESSION['role'] == 10){
               $where = "WHERE leave_record.`status` = '8' ";     
           }
           else{
               $where = " ";     
           }
            return $this->conn->query("SELECT
                leave_record.pk_id,
	tbl_warehouse.wh_name, 
	tbl_locations.LocName, 
	designation.designation, 
	leave_types.leave_type, 
	users.username AS name, 
	leave_record.bps, 
	leave_record.comm_date, 
	leave_record.no_of_days
FROM
	leave_record
	INNER JOIN
	tbl_locations
	ON 
		leave_record.curr_district = tbl_locations.PkLocID
	INNER JOIN
	tbl_warehouse
	ON 
		leave_record.curr_station = tbl_warehouse.wh_id
	INNER JOIN
	designation
	ON 
		leave_record.designation = designation.id
	INNER JOIN
	leave_types
	ON 
		leave_record.leave_nature = leave_types.pk_id
	INNER JOIN
	users
	ON 
		leave_record.user_id = users.pk_id $where");
            
             return $this->conn->query($strSql);

    }
         public function create_leave_letter() {
           
            return $this->conn->query("SELECT
	leave_record.pk_id,
	leave_record.comm_date,
	leave_record.no_of_days,
	tbl_warehouse.wh_name,
	designation.designation,
	users.username 
FROM
	leave_record
	INNER JOIN tbl_warehouse ON leave_record.curr_station = tbl_warehouse.wh_id
	INNER JOIN designation ON leave_record.designation = designation.id
	INNER JOIN users ON leave_record.user_id = users.pk_id
        WHERE
	leave_record.notification_date IS NULL");
             return $this->conn->query($strSql);

    }
         public function total_leave_letter() {
           
            return $this->conn->query("SELECT
	leave_record.pk_id,
	leave_record.comm_date,
	leave_record.no_of_days,
	tbl_warehouse.wh_name,
	designation.designation,
	users.username 
FROM
	leave_record
	INNER JOIN tbl_warehouse ON leave_record.curr_station = tbl_warehouse.wh_id
	INNER JOIN designation ON leave_record.designation = designation.id
	INNER JOIN users ON leave_record.user_id = users.pk_id
        WHERE
	leave_record.notification_date IS NOT NULL");
             return $this->conn->query($strSql);

    }
     public function transfer_summary() {     
            return $this->conn->query("SELECT
	COUNT(transfer_record.pk_id) AS total, 
	app_status.action
FROM
	transfer_record
	INNER JOIN
	app_status
	ON 
		transfer_record.`status` = app_status.pk_id
GROUP BY
	transfer_record.`status` ");
            
             return $this->conn->query($strSql);

    }
       public function transfer_info() {
           if($_SESSION['role'] == 7){
               $where = "WHERE transfer_record.`status` = '1' ";     
           }
           elseif($_SESSION['role'] == 8){
               $where = "WHERE transfer_record.`status` = '3' ";     
           }
            elseif($_SESSION['role'] == 9){
               $where = "WHERE transfer_record.`status` = '5' ";     
           }
           elseif($_SESSION['role'] == 10){
               $where = "WHERE transfer_record.`status` = '7' ";     
           }
           else{
               $where = " ";     
           }          
            return $this->conn->query("SELECT
	transfer_record.pk_id,
	transfer_record.bps,
	users.username AS `name`,
	tbl_locations.LocName AS domicile,
	designation.designation,
	tbl_warehouse.wh_name,
	app_status.action AS `status`,
	curr_district.LocName AS curr_district,
	p1.LocName AS p1,
	p2.LocName AS p2,
	p3.LocName AS p3 
FROM
	transfer_record
	INNER JOIN users ON transfer_record.user_id = users.pk_id
	INNER JOIN tbl_locations ON transfer_record.domicile = tbl_locations.PkLocID
	INNER JOIN designation ON transfer_record.designation = designation.id
	INNER JOIN tbl_warehouse ON transfer_record.curr_station = tbl_warehouse.wh_id
	INNER JOIN app_status ON transfer_record.`status` = app_status.pk_id
	INNER JOIN tbl_locations AS curr_district ON transfer_record.curr_district = curr_district.PkLocID
	INNER JOIN tbl_locations AS p1 ON transfer_record.p1 = p1.PkLocID
	INNER JOIN tbl_locations AS p2 ON transfer_record.p2 = p2.PkLocID
	INNER JOIN tbl_locations AS p3 ON transfer_record.p3 = p3.PkLocID $where");          
             return $this->conn->query($strSql);
    }
    
     public function transfer_returned() {
           if($_SESSION['role'] == 6){
               $where = "WHERE transfer_record.`status` = '10' ";     
           }
           else{
               $where = " ";     
           }          
            return $this->conn->query("SELECT
	transfer_record.pk_id,
	transfer_record.bps,
	users.username AS `name`,
	tbl_locations.LocName AS domicile,
	designation.designation,
	tbl_warehouse.wh_name,
	app_status.action AS `status`,
	curr_district.LocName AS curr_district,
	p1.LocName AS p1,
	p2.LocName AS p2,
	p3.LocName AS p3 
FROM
	transfer_record
	INNER JOIN users ON transfer_record.user_id = users.pk_id
	INNER JOIN tbl_locations ON transfer_record.domicile = tbl_locations.PkLocID
	INNER JOIN designation ON transfer_record.designation = designation.id
	INNER JOIN tbl_warehouse ON transfer_record.curr_station = tbl_warehouse.wh_id
	INNER JOIN app_status ON transfer_record.`status` = app_status.pk_id
	INNER JOIN tbl_locations AS curr_district ON transfer_record.curr_district = curr_district.PkLocID
	INNER JOIN tbl_locations AS p1 ON transfer_record.p1 = p1.PkLocID
	INNER JOIN tbl_locations AS p2 ON transfer_record.p2 = p2.PkLocID
	INNER JOIN tbl_locations AS p3 ON transfer_record.p3 = p3.PkLocID $where");          
             return $this->conn->query($strSql);
    }
    
        public function total_transfer_letter() {
           
            return $this->conn->query("SELECT
		transfer_management.pk_id, 
	transfer_management.posting_form_no,   
	transfer_management.current_district, 
	transfer_management.current_office, 
	transfer_management.transfer_to_district, 
	transfer_management.transfer_to_office, 
	transfer_management.proposed_date
FROM
	transfer_management
	INNER JOIN
	personal_record
	ON 
		transfer_management.personal_record_id = personal_record.pk_id");
             return $this->conn->query($strSql);

    }
    public function rejected_transfer() {
       
           if($_SESSION['role'] == 7){
               $where = "WHERE transfer_record.`status` = '2' ";     
           }
           elseif($_SESSION['role'] == 8){
               $where = "WHERE transfer_record.`status` = '4' ";     
           }
            elseif($_SESSION['role'] == 9){
               $where = "WHERE transfer_record.`status` = '6' ";     
           }
           elseif($_SESSION['role'] == 10){
               $where = "WHERE transfer_record.`status` = '8' ";     
           }
           else{
               $where = " ";     
           }
           
            return $this->conn->query("SELECT
	transfer_record.pk_id,
	transfer_record.bps,
	users.username AS `name`,
	tbl_locations.LocName AS domicile,
	designation.designation,
	tbl_warehouse.wh_name,
	app_status.action AS `status`,
	curr_district.LocName AS curr_district,
	p1.LocName AS p1,
	p2.LocName AS p2,
	p3.LocName AS p3 
FROM
	transfer_record
	INNER JOIN users ON transfer_record.user_id = users.pk_id
	INNER JOIN tbl_locations ON transfer_record.domicile = tbl_locations.PkLocID
	INNER JOIN designation ON transfer_record.designation = designation.id
	INNER JOIN tbl_warehouse ON transfer_record.curr_station = tbl_warehouse.wh_id
	INNER JOIN app_status ON transfer_record.`status` = app_status.pk_id
	INNER JOIN tbl_locations AS curr_district ON transfer_record.curr_district = curr_district.PkLocID
	INNER JOIN tbl_locations AS p1 ON transfer_record.p1 = p1.PkLocID
	INNER JOIN tbl_locations AS p2 ON transfer_record.p2 = p2.PkLocID
	INNER JOIN tbl_locations AS p3 ON transfer_record.p3 = p3.PkLocID  $where");
            
             return $this->conn->query($strSql);

    }
     public function approved_transfer() {
       
           if($_SESSION['role'] == 7){
               $where = "WHERE transfer_record.`status` > '2' ";     
           }
           elseif($_SESSION['role'] == 8){
               $where = "WHERE transfer_record.`status` > '4' ";     
           }
            elseif($_SESSION['role'] == 9){
               $where = "WHERE transfer_record.`status` > '6' ";     
           }
           elseif($_SESSION['role'] == 10){
               $where = "WHERE transfer_record.`status` > '8' ";     
           }
           else{
               $where = " ";     
           }
           
            return $this->conn->query("SELECT
	transfer_record.pk_id,
	transfer_record.bps,
	users.username AS `name`,
	tbl_locations.LocName AS domicile,
	designation.designation,
	tbl_warehouse.wh_name,
	app_status.action AS `status`,
	curr_district.LocName AS curr_district,
	p1.LocName AS p1,
	p2.LocName AS p2,
	p3.LocName AS p3 
FROM
	transfer_record
	INNER JOIN users ON transfer_record.user_id = users.pk_id
	INNER JOIN tbl_locations ON transfer_record.domicile = tbl_locations.PkLocID
	INNER JOIN designation ON transfer_record.designation = designation.id
	INNER JOIN tbl_warehouse ON transfer_record.curr_station = tbl_warehouse.wh_id
	INNER JOIN app_status ON transfer_record.`status` = app_status.pk_id
	INNER JOIN tbl_locations AS curr_district ON transfer_record.curr_district = curr_district.PkLocID
	INNER JOIN tbl_locations AS p1 ON transfer_record.p1 = p1.PkLocID
	INNER JOIN tbl_locations AS p2 ON transfer_record.p2 = p2.PkLocID
	INNER JOIN tbl_locations AS p3 ON transfer_record.p3 = p3.PkLocID  $where");
            
             return $this->conn->query($strSql);

    }
     public function transfer_report() {
       
//           if($_SESSION['role'] == 7){
//               $where = "WHERE transfer_record.`status` > '2' ";     
//           }
//           elseif($_SESSION['role'] == 8){
//               $where = "WHERE transfer_record.`status` > '4' ";     
//           }
//            elseif($_SESSION['role'] == 9){
//               $where = "WHERE transfer_record.`status` > '6' ";     
//           }
//           elseif($_SESSION['role'] == 10){
//               $where = "WHERE transfer_record.`status` > '8' ";     
//           }
//           else{
//               $where = " ";     
//           }
           
            return $this->conn->query("SELECT
	transfer_record.pk_id, 
 	users.username AS name, 
        transfer_record.bps, 
	tbl_locations.LocName AS domicile, 
      	tbl_warehouse.wh_name, 
	city.LocName AS curr_city, 
	transfer_record.created_date, 
	transfer_record.scruitiny_date, 
	transfer_record.hrm_date, 
	transfer_record.commitee_date, 
	transfer_record.sect_date, 
	app_status.action
FROM
	transfer_record
	INNER JOIN
	tbl_locations
	ON 
		transfer_record.domicile = tbl_locations.PkLocID
	INNER JOIN
	users
	ON 
		transfer_record.user_id = users.pk_id
	INNER JOIN
	tbl_warehouse
	ON 
		transfer_record.curr_station = tbl_warehouse.wh_id
	INNER JOIN
	tbl_locations AS city
	ON 
		transfer_record.curr_district = city.PkLocID
	INNER JOIN
	app_status
	ON 
		transfer_record.`status` = app_status.pk_id
                	ORDER BY created_date ASC");
            
             return $this->conn->query($strSql);

    }

    /**
     * 
     * find_by_id
     * @param type $id
     * @return type
     * 
     * 
     */
    public function find_by_id($id = 0) {
        //select query
        $strSql = "SELECT * FROM " . static::$table_name . " WHERE pk_id={$id} LIMIT 1";
        //query result
        return $this->conn->query($strSql);
    }
    public function get_sanc_id($id = 0) {
        //select query
//        $strSql = "SELECT * FROM " . static::$table_name . " WHERE post_id={$id} LIMIT 1";
        $strSql = "SELECT
                        *
                FROM
                        sanctioned_desg_record
                INNER JOIN posts_record ON posts_record.parent_post_name = sanctioned_desg_record.pk_id
                WHERE
                        posts_record.pk_id = {$id}
                LIMIT 1
                ";
//        echo $strSql;        exit();
        //query result
        return $this->conn->query($strSql);
    }
    
    public function sanctioneddropdown(){
    
	 $sql =  "SELECT
                            *
                    FROM
                            `sanctioned_desg_record`
                    WHERE
                            is_active = 1 ";
         
         return $this->conn->query($sql);	
}


    /**
     * 
     * find_by_id
     * @param type $id
     * @return type
     * 
     * 
     */
//    public function find_by_personal($id = 0) 
//            {
//        //select query
//        $strSql = "SELECT DISTINCT
//        specialities_record.pk_id,
//        specialities_record.sanctioned_desg
//        FROM
//        personal_specialities
//        INNER JOIN specialities_record ON personal_specialities.specility_id = specialities_record.pk_id
//        WHERE
//        personal_specialities.personal_record_id = $id";
//        //query result
//        return $this->conn->query($strSql);
//    }

    /**
     * 
     * count_all
     * @global type $this->conn
     * @return type
     * 
     * 
     */
    public function count_all() {
        //select query
        $sql = "SELECT COUNT(*) FROM " . static::$table_name;
        //query result
        $result_set = $this->conn->query($sql);
        $row = $this->conn->fetch_array($result_set);
        return array_shift($row);
    }

    /**
     * 
     * instantiate
     * @param type $record
     * @return \self
     * 
     * 
     */
    private function instantiate($record) {
        // Could check that $record exists and is an array
        $object = new self;
        // Simple, long - form approach:
        // More dynamic, short - form approach:
        foreach ($record as $attribute => $value) {
            if ($object->has_attribute($attribute)) {
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    /**
     * 
     * has_attribute
     * @param type $attribute
     * @return type
     * 
     * 
     */
    private function has_attribute($attribute) {
        // We don't care about the value, we just want to know if the key exists
        // Will return true or false
        return array_key_exists($attribute, $this->attributes());
    }

    /**
     * 
     * attributes
     * @return type
     * 
     * 
     */
    protected function attributes() {
        // return an array of attribute names and their values
        $attributes = array();
        foreach (static::$db_fields as $field) {
            if (property_exists($this, $field)) {
                $attributes[$field] = $this->$field;
            }
        }
        return $attributes;
    }

    /**
     * 
     * sanitized_attributes
     * @global type $this->conn
     * @return type
     * 
     * 
     */
    protected function sanitized_attributes() {
        $clean_attributes = array();
        // sanitize the values before submitting
        // Note: does not alter the actual value of each attribute
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $this->conn->escape_value($value);
        }
        return $clean_attributes;
    }

    /**
     * 
     * save
     * @return type
     * 
     * 
     */
    public function save() {
        // A new record won't have an id yet.
        return isset($this->pk_id) ? $this->update() : $this->create();
    }

    /**
     * create
     * @global type $this->conn
     * @return boolean
     */
    public function create() {
        // Don't forget your SQL syntax and good habits:
        // - INSERT INTO table (key, key) VALUES ('value', 'value')
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();

        $sql = "INSERT INTO " . static::$table_name . " (";
        $sql .= join(", ", array_keys($attributes));
        $sql .= ") VALUES ('";
        $sql .= join("', '", array_values($attributes));
        $sql .= "')";
//        echo $sql;exit;
        if ($this->conn->query($sql)) {
            return $this->conn->insert_id();
        } else {
            return false;
        }
    }

    /**
     * update
     * @global type $this->conn
     * @return type
     */
    public function update() {
        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE pk_id=" . $this->conn->escape_value($this->pk_id);
        $this->conn->query($sql);
        return true;
    }
    
    /**
     * upload
     * @global type $this->conn
     * @return type
     */
    public function upload() {
        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= " picture = '".$this->picture."' WHERE pk_id=" . $this->conn->escape_value($this->pk_id);
        $this->conn->query2($sql);
        return true;
    }

    /**
     * 
     * delete
     * @global type $this->conn
     * @return type
     * 
     * 
     */
    public function delete() {
        // Don't forget your SQL syntax and good habits:
        // - DELETE FROM table WHERE condition LIMIT 1
        // - escape all values to prevent SQL injection
        // - use LIMIT 1
        //delete query
        $sql = "DELETE FROM " . static::$table_name;
        $sql .= " WHERE pk_id=" . $this->conn->escape_value($this->pk_id);
        $sql .= " LIMIT 1";
        return $this->conn->query2($sql);
    }

    public function is_active() {
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= " is_active = " . $this->is_active;
        $sql .= " WHERE pk_id=" . $this->conn->escape_value($this->pk_id);
        return $this->conn->query2($sql);
    }

}

#####################
Batch Text Replacer Demo ID:722870789
#####################
