<?php

require_once 'database.php';


class roles {

    
    protected static $table_name = "roles";
    
    private $conn;
    
    protected static $db_fields = array('role_name','is_active');
   
public $pk_id;
public $role_name;
public $is_active;


public function __construct() {
        $this->conn = new database();
    }

    
    public function find_all() {
        if ($_SESSION['role'] == 1) {

               $strSql = "SELECT DISTINCT
               roles.*,
               GROUP_CONCAT( DISTINCT role_actions.action ) permission
           FROM
               roles
               LEFT JOIN role_actions ON role_actions.role_id = roles.pk_id 
           GROUP BY
               roles.pk_id 
           ORDER BY
               roles.pk_id" ;
               
              
        
        return $this->conn->query($strSql);
            
           
        } else {

              $strSql = "SELECT DISTINCT
              roles.*,
              GROUP_CONCAT( DISTINCT role_actions.action ) permission
          FROM
              roles
              LEFT JOIN role_actions ON role_actions.role_id = roles.pk_id 
          GROUP BY
              roles.pk_id 
          ORDER BY
              roles.pk_id" ;
              
              
        
        return $this->conn->query($strSql);
            
        }
    }


    public function find_by_id($id = 0) {
        
        $strSql = "SELECT * FROM " . static::$table_name . " WHERE pk_id={$id} LIMIT 1";
        
        return $this->conn->query($strSql);
    }
    
        public function roledropdown(){
    
	 $sql =  "SELECT * FROM `roles` WHERE is_active = 1 ORDER BY role_value";
         
         return $this->conn->query($sql);	
     }

    
  public function selectdata4($children_id=null){
   
      
        $strSql = "SELECT * FROM " . static::$table_name ;
        
	if(!empty($children_id)){
            
            $strSql .= " WHERE pk_id = $children_id ";
          
        }
      
	      return $this->conn->query($strSql);
}

    public function find_by_family($id = 0) 
     {
        
   $strSql = "SELECT DISTINCT
	childrens_record.pk_id,
	childrens_record.name,
	childrens_record.date_of_birth,
	childrens_record.school_name
        FROM
	childrens_record
        INNER JOIN family_record ON childrens_record.family_record_id = family_record.pk_id
        WHERE
	childrens_record.family_record_id = $id";
       
        return $this->conn->query($strSql);
    }
    
    public function find_by_department($id = 0) {
       
        $strSql = "SELECT * FROM " . static::$table_name . " WHERE department_id={$id}";
        
        return $this->conn->query($strSql);
    }

   
    public function count_all() {
        
        $sql = "SELECT COUNT(*) FROM " . static::$table_name;
        
        $result_set = $this->conn->query($sql);
        $row = $this->conn->fetch_array($result_set);
        return array_shift($row);
    }

    private function instantiate($record) {
        
        $object = new self;
        
        foreach ($record as $attribute => $value) {
            if ($object->has_attribute($attribute)) {
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    private function has_attribute($attribute) {
        
        return array_key_exists($attribute, $this->attributes());
    }

    
    protected function attributes() {
      
        $attributes = array();
        foreach (static::$db_fields as $field) {
            if (property_exists($this, $field)) {
                $attributes[$field] = $this->$field;
            }
        }
        return $attributes;
    }
    protected function sanitized_attributes() {
        $clean_attributes = array();
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $this->conn->escape_value($value);
        }
        return $clean_attributes;
    }

    public function save() {
        
        return isset($this->pk_id) ? $this->update() : $this->create();
    }

    public function create() {
        $attributes = $this->sanitized_attributes();

        $sql = "INSERT INTO " . static::$table_name . " (";
        $sql .= join(", ", array_keys($attributes));
        $sql .= ") VALUES ('";
        $sql .= join("', '", array_values($attributes));
        $sql .= "')";
        if ($this->conn->query($sql)) {
            return $this->conn->insert_id();
        } else {
            return false;
        }
    }

    public function update() {
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE pk_id=" . $this->conn->escape_value($this->pk_id);
        $this->conn->query($sql);
        return true;
    }
    
    public function upload() {
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= " picture = '".$this->picture."' WHERE pk_id=" . $this->conn->escape_value($this->pk_id);
        $this->conn->query2($sql);
        return true;
    }

    
    public function delete() {
        
        $sql = "DELETE FROM " . static::$table_name;
        $sql .= " WHERE pk_id=" . $this->conn->escape_value($this->pk_id);
        

        
        $sql .= " LIMIT 1";
        return $this->conn->query2($sql);
    }

    public function is_active() {
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= " is_active = " . $this->is_active;
        $sql .= " WHERE pk_id=" . $this->conn->escape_value($this->pk_id);
        return $this->conn->query2($sql);
    }

}