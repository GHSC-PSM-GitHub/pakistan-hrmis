<?php

if (!function_exists('start_table')) {
    function start_table($id, $columns) {
        $html ='<table id="'.$id.'" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">';
        $html .= "<thead><tr>";
        foreach($columns as $column){
            $html .= "<th>".$column."</th>";                
        }
        $html .= "</tr>
            </thead><tbody>";
        return $html;
    }
}

if (!function_exists('end_table')) {
    function end_table() {                
        $html ='</tbody></table>';
       return $html;
    }
}

if (!function_exists('create_multi_combo')) {
    function create_multi_combo($name, $data, $sel_val = '') {            
        $html ='<select multiple class="form-control" id="'.$name.'" name="'.$name.'" required>';
        if(isset($data)){
            if(is_object($data)){
                while ($row = $data->fetch_object()) {
                    $sel = '';
                    if($sel_val == $row->key){
                        $sel = "selected=selected";
                    }
                    $html .= "<option value=".$row->key." $sel>".$row->value."</option>";
                }
            } else {
                foreach ($data as $key=>$value) {
                    $sel = '';
                    if($sel_val == $key){
                        $sel = "selected=selected";
                    }
                    $html .= "<option value=".$key." $sel>".$value."</option>";
                }
            }
        }
        $html .= "</select>";
        return $html;
    }
}

if (!function_exists('create_combo')) {
    function create_combo($name, $data, $sel_val = '') {            
        $html ='<select class="span12" id="'.$name.'" name="'.$name.'">';
        $html .= '<option value=>Select</option>';
        if(isset($data)){
            if(is_object($data)){
                while ($row = $data->fetch_object()) {
                    $sel = '';
                    if($sel_val == $row->key){
                        $sel = "selected=selected";
                    }
                    $html .= "<option value=".$row->key." $sel>".$row->value."</option>";
                }
            } else {
                foreach ($data as $key=>$value) {
                    $sel = '';
                    if($sel_val == $key){
                        $sel = "selected=selected";
                    }
                    $html .= "<option value=".$key." $sel>".$value."</option>";
                }
            }
        }
        $html .= "</select>";
        return $html;
    }
}