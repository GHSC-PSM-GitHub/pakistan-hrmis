<?php
$url  = isset($_SERVER['HTTPS']) ? 'https://' : 'http://';
$url .= ($_SERVER['SERVER_NAME']=='localhost' || $_SERVER['SERVER_NAME']=='127.0.0.1' ? $_SERVER['SERVER_NAME']."/hrmis" : $_SERVER['SERVER_NAME']);

define('BASE_PATH',dirname(__DIR__));
define('BASE_URL', $url);