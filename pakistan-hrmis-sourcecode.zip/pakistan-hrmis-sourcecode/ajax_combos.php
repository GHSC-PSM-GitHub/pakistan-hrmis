#####################
Batch Text Replacer Demo ID:921884
#####################
<?php

/**
 * ajax_combos
 * @package reports
 * 

 * 
 * @version    2.2
 * 
 */
//include AllClasses
include 'classes/config.php'; 
//get SkOfcLvl
$skOfcLvl = isset($_REQUEST['SkOfcLvl']) ? $_REQUEST['SkOfcLvl'] : '';
//get provId
$provId = isset($_REQUEST['provId']) ? $_REQUEST['provId'] : '';
//get distId
$distId = isset($_REQUEST['distId']) ? $_REQUEST['distId'] : '';
//get tehsilId
$tehsilId = isset($_REQUEST['tehsilId']) ? $_REQUEST['tehsilId'] : '';
//get ucId
$ucId = isset($_REQUEST['ucId']) ? $_REQUEST['ucId'] : '';
//get provSelId
$provSelId = isset($_REQUEST['provSelId']) ? $_REQUEST['provSelId'] : '';
//get distSelId
$did = isset($_REQUEST['distIdSelId']) ? $_REQUEST['distIdSelId'] : '';

$distSelId = isset($_REQUEST['distSelId']) ? $_REQUEST['distSelId'] : '';
//get tehSelId
$hfId = isset($_REQUEST['tehSelId']) ? $_REQUEST['tehSelId'] : '';

$tehSelId = '';
//$tehSelId = isset($_REQUEST['tehSelId']) ? $_REQUEST['tehSelId'] : '';

$ucSelId = isset($_REQUEST['ucSelId']) ? $_REQUEST['ucSelId'] : '';

if ($skOfcLvl != 1 && empty($provId) && empty($distSelId)) {
//    echo "<option value=\"all\">All</option>";
//query 
    //gets
    //PkLocID
    //LocName
    $qry = "SELECT
                tbl_locations.LocName,
                tbl_locations.PkLocID
                FROM
                tbl_locations
                WHERE
                tbl_locations.LocLvl = 2 AND
                tbl_locations.PkLocID = 1
                        ";
    //query result
//    echo $qry;
//    exit;
    $rsQry = mysqli_query($conn,$qry);
    //fetch data from rsQry
    while ($row = mysqli_fetch_array($rsQry)) {
        if ($provSelId == $row['PkLocID']) {
            $sel = "selected='selected'";
        } else {
            $sel = "";
        }
        ?>
        <option value="<?php echo $row['PkLocID']; ?>" <?php echo $sel; ?>><?php echo $row['LocName']; ?></option>
        <?php
    }
}
if ($skOfcLvl != 1 && !empty($provId) && empty($distSelId)) {
    
    //query 
    //gets
    //PkLocID
    //LocName
    if($skOfcLvl == 7)
    {
        echo "<option value='63'>All</option>";
    $qry = "SELECT
                tbl_locations.LocName,
                tbl_locations.PkLocID
                FROM
                tbl_locations
                WHERE
                tbl_locations.ParentID = $provId AND
                tbl_locations.LocLvl = 3
                AND tbl_locations.PkLocID = 63
                ";
    }
    else{
        echo "<option value=\"all\">All</option>";
        
        
        $qry = "SELECT
                tbl_locations.LocName,
                tbl_locations.PkLocID
                FROM
                tbl_locations
                WHERE
                tbl_locations.ParentID = $provId AND
                tbl_locations.LocLvl = 3
                ";
    }
//    echo $qry;
//    exit;
    //query result
    $rsQry = mysqli_query($conn,$qry);
    //fetch data from rsQry
    while ($row = mysqli_fetch_array($rsQry)) {
        if ($did == $row['PkLocID']) {
            $sel = "selected='selected'";
        } else {
            $sel = "";
        }
        ?>
        <option value="<?php echo $row['PkLocID']; ?>" <?php echo $sel; ?>><?php echo $row['LocName']; ?></option>
        <?php
    }
}
if ($skOfcLvl != 1 && !empty($distSelId) && empty($tehSelId)) {
    echo "<option value=\"all\">All</option>";
    
    $qry = "SELECT
                tbl_warehouse.wh_id,
                tbl_warehouse.wh_name
                FROM
                tbl_warehouse
                WHERE
                tbl_warehouse.prov_id = $provId AND
                tbl_warehouse.dist_id = $distSelId";
//    echo $qry;
//    exit;
    //query result
    $rsQry = mysqli_query($conn,$qry) or die();
    //fetch data from rsQry
    while ($row = mysqli_fetch_array($rsQry)) {
        if ($hfid == $row['wh_id']) {
            $sel = "selected='selected'";
        } else {
            $sel = "";
        }
        ?>
        <option value="<?php echo $row['wh_id']; ?>" <?php echo $sel; ?>><?php echo $row['wh_name']; ?></option>
        <?php
    }
}
//if ($skOfcLvl != 1 && !empty($tehSelId) && empty($ucSelId)) {
//    echo "<option value=\"all\">All</option>";
//      $qry = "SELECT
//	locations.location_name tehsil,
//	locations.location_name uc,
//        locations.pk_id pk_id
//FROM
//	locations
//WHERE
//	locations.province_id = $provId
//            AND locations.district_id = $distSelId
//AND locations.parent_id = $tehSelId
//AND geo_level_id = 6
//GROUP BY 
//locations.location_name
//ORDER BY
//	locations.location_name,
//	locations.location_name";
////    echo $qry;
////    exit;
//    //query result
//    $rsQry = mysqli_query($conn,$qry) or die();
//    //fetch data from rsQry
//    while ($row = mysqli_fetch_array($rsQry)) {
//        if ($tehSelId == $row['pk_id']) {
//            $sel = "selected='selected'";
//        } else {
//            $sel = "";
//        }
//        ?>
        <!--<option value="<?php echo $row['pk_id']; ?>" <?php echo $sel; ?>><?php echo $row['uc']; ?></option>-->
        <?php
//    }
//}
//if ($skOfcLvl != 1 && !empty($ucSelId)) {
//    echo "<option value=\"all\">All</option>";
//    $qry = "SELECT
//	warehouses.warehouse_name,
//	warehouses.pk_id
//FROM
//	warehouses
//INNER JOIN locations ON warehouses.location_id = locations.pk_id
//WHERE
//	warehouses.district_id = $distSelId
//AND warehouses.province_id = $provId
//AND warehouses.location_id = $ucSelId
//ORDER BY
//	warehouse_name";
////    echo $qry;
////    exit;
//    $rsQry = mysqli_query($conn,$qry) or die();
//    //fetch data from rsQry
//    while ($row = mysqli_fetch_array($rsQry)) {
//        if ($tehSelId == $row['pk_id']) {
//            $sel = "selected='selected'";
//        } else {
//            $sel = "";
//        }
//        ?>
        <!--<option value="<?php echo $row['pk_id']; ?>" <?php echo $sel; ?>><?php echo $row['warehouse_name']; ?></option>-->
        <?php
//    }
//}

#####################
Batch Text Replacer Demo ID:3913667
#####################
