<?php
require_once 'classes/post.php';
require_once 'classes/sanctioned_desg.php';
require_once 'classes/datetime.php';

$post = new post();
$sanc = new sanctioned_desg();
$file_id = $_POST['id'];
$file = $post->find_by_id($file_id);
$data = $file->fetch_array();
?>
<!-- Row -->
<div class="row-fluid">
    <!-- Column -->
    <div class="span12">
        <!-- Group -->
<!--        <div class="control-group">
            <label class="control-label" for="name">Name</label>
            <div class="controls"><input class="span12" id="name" name="name" type="text" value="<?php echo $data['name']; ?>" /></div>
        </div>                        -->
         <div class="control-group">
            <label class="control-label" for="designation">Designation</label>
            <div class="controls"><input class="span12" id="designation" name="designation" type="text" value="<?php echo $data['designation']; ?>" required/></div>
        </div>  
<!--        <div class="control-group">
            <label class="control-label" for="designation">Parent Name</label>
            <div class="controls"><input class="span12" id="parent_name" name="parent_name" type="text" /></div>
        </div>  -->
         <?php
//                        $list = new post();
                        $result = $sanc->find_all();

                        $rowCount = $result->num_rows;
                        ?>
                        <!--<div class="span4">-->
                            <div class="control-group">
                                <label class="control-label" for="parent_name">Sanctioned Designation </label>
                                <div class="controls">
                                    <select class="span12" name="parent_name" id="parent_name">
                                        <option value="">Select</option>
                                        <?php
                                        //echo "<pre>".print_r($data)."</pre>";
                                        if ($rowCount > 0) {
                                            while ($row = $result->fetch_array()) {
                                                $sel ="";
                                                if($data['parent_post_name'] == $row['pk_id']) {
                                                    $sel = "selected=selected";
                                                }
                                                echo '<option value="' . $row['pk_id'] . '" '.$sel.'>' . $row['sanctioned_desg'] . '</option>';
                                            }
                                        } else {
                                            echo '<option value="">Post not available</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                        <!--</div>-->
          <div class="control-group">
            <label class="control-label" for="bps">Bps</label>
            <div class="controls"><input class="span12" id="bps" name="bps" type="text" value="<?php echo $data['bps']; ?>" /></div>
          </div>  
<!--        <div class="control-group">
            <label class="control-label" for="direct">By Direct</label>
            <div class="controls"><input class="span12" placeholder="%" min="0" max="100" id="direct" name="direct" value="<?php echo $data['direct']; ?>" type="number" /></div>
        </div>  
        <div class="control-group">
            <label class="control-label" for="promotion">By Promotion</label>
            <div class="controls"><input class="span12" id="promotion" min="0" max="" placeholder="%" name="promotion" value="<?php echo $data['promotion']; ?>" type="number" /></div>
        </div>  -->
    </div>
    <!-- // Column END -->



</div>

<input type="hidden" name="fileid" value="<?php echo $file_id; ?>"/>

<script>
//    $(document).ready(function() {
//            $('#direct').keyup(function() {
//                var dInput = 100-($(this).val());
//        //        if(dInput < 100)
//        //        {
//        //            var res = 100-dInput;
//        //        }
//                $('#promotion').attr('max', dInput);
//        //        $('#promotion').data('max',res);
//            });
//        });
</script>