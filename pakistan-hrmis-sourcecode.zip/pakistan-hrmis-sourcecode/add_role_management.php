<?php

session_start();
require_once 'classes/roles.php';

require_once 'classes/datetime.php';

$reward = new roles();
//$file = $reward->save();


if(isset($_REQUEST['fileid']) && !empty($_REQUEST['fileid'])){
    $reward->pk_id = $_REQUEST['fileid'];
}
$reward->role_name = $_POST['role_name'];
$reward->created_date = date("Y-m-d");
$reward->is_active = 1;

$file = $reward->save();

if ($file) {
    header("location: roles_management.php");
} else {
    header("location: roles_management.php");
}
