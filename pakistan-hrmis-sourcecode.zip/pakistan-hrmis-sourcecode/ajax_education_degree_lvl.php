<?php
require_once 'classes/degree.php';
require_once 'classes/datetime.php';
$degree = new degree();
$d_level = $_POST['d_level'];
$result = $degree->degreedropdown($d_level);
//$data = $result->fetch_array();
?>
<!-- Row -->
<!-- Group -->
                            <?php
//                            $list = new degree();
//                            echo $result = $list->degreedropdown();
                            if($result)
                            {
                                $rowCount = $result->num_rows;
                            }else {
                                $rowCount = 0;
                            }?>
                            <!--<div class="control-group">-->
                                <label class="control-label" for="degree_id">Degree Name </label>
                                <div class="controls">
                                    <!--<div class="controls"><input class="span12" id="degree_id" name="degree_id" type="text" /></div>-->
                                    <select class="span12" name="degree_id" id="degree_id">
                                        <option value="">Select</option>

                                        <?php
                                        if ($rowCount > 0) {

                                            while ($row = $result->fetch_array()) {

                                                echo '<option value="' . $row['pk_id'] . '">' . $row['degree_title'] . '</option>';
                                            }
                                        } else {
                                            echo '<option value="">Degree not available</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                            <!--</div>-->