<?php

session_start();
require_once 'classes/marital_status.php';

require_once 'classes/datetime.php';

$speciality = new marital_status();
//$file = $speciality->save();

if(isset($_REQUEST['fileid']) && !empty($_REQUEST['fileid'])){
    $speciality->pk_id = $_REQUEST['fileid'];
}
$speciality->marital_status = $_POST['marital_status'];
$speciality->is_active = 1;

$file = $speciality->save();

if ($file) {
    header("location: marital_status_record.php");
} else {
    header("location: marital_status_record.php");
}