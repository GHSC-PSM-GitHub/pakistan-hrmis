<?php
session_start();
require_once 'classes/family.php';

$family = new family();

if (isset($_REQUEST['familyid']) && !empty($_REQUEST['familyid'])) {
    $family->pk_id = $_REQUEST['familyid'];
}

$family->spouse_name = $_POST['spouse_name'];
$family->personal_record_id = $_POST['pers_spouse_id'];
$family->health_professional = $_POST['is_health_professional'];
$family->spouse_designation = $_POST['spouse_designation'];
$family->spouse_office = $_POST['spouse_office'];
if(isset($_POST['pers_spouse_id']) & !empty($_POST['pers_spouse_id']))
{
$family_id = $family->save();
//echo $_POST['pers_spouse_id'];
$result = $family->find_by_personal($_POST['pers_spouse_id']);

if ($result) {
    ?>
    <!-- Table -->

    <table class="table table-striped table-bordered table-condensed">
        <thead>
            <tr>
                <th style="width: 1%;" class="center">No.</th>
                <th>Health Professional?</th>
                <th>Spouse Name</th>
                <th>Spouse Office</th>
                <th>Spouse Designation</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <!-- Table row -->
            <?php
            $count = 1;
            while ($row = $result->fetch_array()) {

                $class = "gradeX";
                if ($count % 2 == 0) {
                    $class = "gradeC";
                }
                //$attchment = new attachments();
                //$att_count = $attchment->count_all($row['pk_id']);
                ?>
                <tr class="<?php echo $class; ?>">
                    <td class="center"><?php echo $count; ?></td>
                    <td><?php echo $row['health_professional']; ?></td>
                    <td class="important"><?php echo $row['spouse_name']; ?></td>
                    <td class="important"><?php echo !empty($row['spouse_office']) ? $row['spouse_office'] : 'N/A' ; ?></td>
                    <td class="important"><?php echo !empty($row['spouse_designation']) ? $row['spouse_designation'] : 'N/A'; ?></td>
                    <td class="center" style="width: 200px;">
                        <a id="<?php echo $row['pk_id']; ?>-delspouse" class="btn-action glyphicons bin" title="delete"><i></i></a>
                    </td>
                </tr>
                <?php
                $count++;
            }
            ?>
            <!-- // Table row END -->
            <!-- Table row -->

            <!-- // Table row END -->
        </tbody>
    </table>
    <!-- // Table END -->
    <?php
} else {
    echo "<hr><h5> No records found!</h5>";
}

}
else
{?>
    <script>alert("Please save employee profile before adding additional information"); </script>
<?php }