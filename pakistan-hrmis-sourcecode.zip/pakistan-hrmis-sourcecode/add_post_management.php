<?php

session_start();
require_once 'classes/post.php';

$post = new post();

if(isset($_REQUEST['fileid']) && !empty($_REQUEST['fileid'])){
    $post->pk_id = $_REQUEST['fileid'];
}

$post->name = $_POST['designation'];
$post->parent_post_name = $_POST['parent_name'];
$post->designation = $_POST['designation'];
$post->bps = $_POST['bps'];
//$post->direct = !empty($_POST['direct']) ? $_POST['direct'] : (100-$_POST['promotion']);
//$post->promotion = !empty($_POST['promotion']) ? $_POST['promotion'] : (100-$_POST['direct']);
$post->created_by = $_SESSION['userid'];
if(isset($_POST['designation']) && !empty($_POST['designation']) && isset($_POST['bps']) && !empty($_POST['bps']))
{
    $file = $post->find_duplicates($_POST['designation'],$_POST['bps'],$_POST['parent_name']);
    if($file->num_rows > 0 && !isset($_REQUEST['fileid']) && empty($_REQUEST['fileid']))
    { ?>
            <script language="javascript">
            alert("Data Already Exists.");
            document.location = "post_record.php";
            </script>
    <?php
    }
    else{
        $file = $post->save();

        if ($file) {
            header("location: post_record.php");
        } else {
            header("location: post_record.php");
        }
    }
}
else{
    header("location: post_record.php");
}