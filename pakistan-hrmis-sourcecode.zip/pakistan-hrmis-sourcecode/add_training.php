<?php

session_start();
require_once 'classes/training.php';
require_once 'classes/personal_training.php';
require_once 'classes/datetime.php';

//$training = new training();
$personal_training = new personaltraining();


if(isset($_REQUEST['personaltrainingid']) && !empty($_REQUEST['personaltrainingid'])){
    $personal_training->pk_id = $_REQUEST['personaltrainingid'];
}


$personal_training->personal_record_id = $_POST['pers_training_id'];
//$personal_training->training_date = $dt->dbformat($_POST['training_date']);
if(isset($_POST['start_year']) && !empty($_POST['start_year']) && !empty($_POST['start_month']) && !empty($_POST['training']))
{
    $personal_training->start_year = $_POST['start_year'];
    $personal_training->start_month = $_POST['start_month'];
    $personal_training->training_id = $_POST['training'];
//    $file = $personal_training->save();
    $check_status_id = $personal_training->check_training_info($_POST['training']);
    while ($row = $check_status_id->fetch_array()) {
        $training_years = $row['years'];
        $training_months = $row['months'];
    }
    $t_year = $training_years + $_POST['start_year'];
    $t_month = $training_months + $_POST['start_month'];
//    $date1 = $t_year.'-'.$t_month;
//    $date2 = $_POST['start_year'].'-'.$_POST['start_month'];
//
//    $diff = abs(strtotime($date2) - strtotime($date1));
//
//    $years = floor($diff / (365*60*60*24));
//    $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
//    $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));

//    printf("%d years, %d months", $years, $months);
    $personal_training->end_year = $t_year;
    $personal_training->end_month = $t_month;
}

//$training->training_date = $_POST['training_date'];

if(isset($_POST['pers_training_id']) & !empty($_POST['pers_training_id']))
{

//$file = $training->save();
$file = $personal_training->save();

$result = $personal_training->find_by_personal($_POST['pers_training_id']);

  if ($result) {
            ?>
            <!-- Table -->

            <table class="dynamicTable table table-striped table-bordered table-condensed">
                <thead>
                    <tr>
                        <th style="width: 1%;" class="center">No.</th>
                        <th>Title</th>
<!--                        <th>Training Date</th>-->
                        <th>Start Year</th>
                        <th>Start Month</th>
                        <th>End Year</th>
                        <th>End Month</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Table row -->
                    <?php
                    $count = 1;
                    while ($row = $result->fetch_array()) {

                        $class = "gradeX";
                        if ($count % 2 == 0) {
                            $class = "gradeC";
                        }
                        //$attchment = new attachments();
                        //$att_count = $attchment->count_all($row['pk_id']);
                        ?>
                        <tr class="<?php echo $class; ?>">
                            <td class="center"><?php echo $count; ?></td>
                            <td><?php echo $row['title']; ?></td>
                            <!--<td class="important"><?php echo $row['training_date']; ?></td>-->
                            <td class="important"><?php echo $row['start_year']; ?></td>
                            <td class="important"><?php echo $row['start_month']; ?></td>
                            <td class="important"><?php echo $row['end_year']; ?></td>
                            <td class="important"><?php echo $row['end_month']; ?></td>
                            <td class="center" style="width: 200px;">
                                <a id="<?php echo $row['pk_id']; ?>-deltraining" class="btn-action glyphicons bin" title="delete"><i></i></a>
                            </td>
                        </tr>
                        <?php
                        $count++;
                    }
                    ?>
                    <!-- // Table row END -->
                    <!-- Table row -->

                    <!-- // Table row END -->
                </tbody>
            </table>
            <!-- // Table END -->
            <?php
        } else {
            echo "<hr><h5> No records found!</h5>";
        }
        
        }
else
{?>
    <script>alert("Please save employee profile before adding additional information"); </script>
<?php }