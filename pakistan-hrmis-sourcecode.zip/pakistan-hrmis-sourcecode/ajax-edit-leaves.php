<?php
require_once 'classes/leaves.php';
require_once 'classes/personal.php';
require_once 'classes/datetime.php';

$personal = new personal();
$post = new leaves();
$file_id = $_POST['id'];
$file = $post->find_by_id($file_id);
$data = $file->fetch_array();
?>
<!-- Row -->
<div class="row-fluid">

    <!-- Column -->
    <div class="span12">

                    <!-- Group -->
                    <div class="control-group">
                        <label class="control-label" for="specility">Employee Name</label>
                        <div class="controls">
                        <?php 
                        $data1 = $personal->get_combo();
                        echo create_combo("employee",$data1,$data['employee_id']); ?>    
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="specility">Kind of Leave</label>
                        <div class="controls">
                        <?php 
                        $data2 = $post->get_combo();
                        echo create_combo("kind_of_leave",$data2,$data['leave_type']); ?>       
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="approved_by">Approved By</label>
                        <div class="controls"><input class="span12" id="approved_by" name="approved_by" type="text" required="" value="<?php echo $data['approved_by']; ?>" /></div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="approved_date">Approved Date</label>
                        <div class="controls"><input class="span12" id="approved_date" name="approved_date" type="text" required="" value="<?php echo $dt->dateformat($data['approved_date']); ?>" /></div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="from_Date">From Date</label>
                        <div class="controls"><input class="span12" id="from_date" name="from_date" type="text" required="" value="<?php echo $dt->dateformat($data['from_date']); ?>" /></div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="to_date">To Date</label>
                        <div class="controls"><input class="span12" id="to_date" name="to_date" type="text" required="" value="<?php echo $dt->dateformat($data['to_date']); ?>" /></div>
                    </div>
                    
                    <div class="control-group">
                        <label class="control-label" for="apointment_letter">Attach file</label>
                        <div class="controls"><input type="file" id="apointment_letter" name="apointment_letter" /></div>
                    </div>
                </div>
    <!-- // Column END -->



</div>

<input type="hidden" name="fileid" value="<?php echo $file_id; ?>"/>