<?php

require_once 'classes/inactive_reason.php';
require_once 'classes/datetime.php';

$inactive_reason = new inactive_reason();
$inactive_reason_id = $_POST['id'];
$file = $inactive_reason->find_by_id($inactive_reason_id);
$data = $file->fetch_array();

?>
<!-- Row -->
<div class="row-fluid">

    <!-- Column -->
    <div class="span12">

        <!-- Group -->                     
        <div class="control-group">
            <label class="control-label" for="inactive_value">Inactive Value</label>
            <div class="controls"><input class="span12" id="inactive_value" name="inactive_value" type="text" value="<?php echo $data['inactive_value']; ?>" /></div>
        </div>                         
    </div>
    <!-- // Column END -->



</div>

<input type="hidden" name="inactive_reasonid" value="<?php echo $inactive_reason_id; ?>"/>