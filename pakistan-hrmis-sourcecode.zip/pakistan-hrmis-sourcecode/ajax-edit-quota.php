<?php
require_once 'classes/quota.php';
require_once 'classes/datetime.php';

$quota = new quota();
$file_id = $_POST['id'];
$file = $quota->find_by_id($file_id);
$data = $file->fetch_array();

?>
<!-- Row -->
<div class="row-fluid">

    <!-- Column -->
    <div class="span12">

        <!-- Group -->
        <div class="control-group">
            <label class="control-label" for="quota">Quota</label>
            <div class="controls"><input class="span12" id="quota" name="quota" type="text" value="<?php echo $data['quota']; ?>" /></div>
        </div>
        <div class="control-group">
            <label class="control-label" for="percentage">Percentage</label>
            <div class="controls"><input class="span12" id="percentage" placeholder="%" value="<?php echo $data['percentage']; ?>" name="percentage" type="text" required="" /></div>
        </div>  
      
    </div>
    <!-- // Column END -->



</div>

<input type="hidden" name="fileid" value="<?php echo $file_id; ?>"/>