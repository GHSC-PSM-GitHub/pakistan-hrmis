<?php

session_start();
require_once 'classes/quota.php';

require_once 'classes/datetime.php';

$quota = new quota();
//$file = $speciality->save();

if(isset($_REQUEST['fileid']) && !empty($_REQUEST['fileid'])){
    $quota->pk_id = $_REQUEST['fileid'];
}
$quota->quota = $_POST['quota'];
$quota->percentage = $_POST['percentage'];
$quota->is_active = 1;

$file = $quota->save();

if ($file) {
    header("location: quota_record.php");
} else {
    header("location: quota_record.php");
}