<?php
require_once 'classes/facility_type.php';
require_once 'classes/datetime.php';

$speciality = new facility();
$file_id = $_POST['id'];
$file = $speciality->find_by_id($file_id);
$data = $file->fetch_array();

?>
<!-- Row -->
<div class="row-fluid">

    <!-- Column -->
    <div class="span12">

        <!-- Group -->
        <div class="control-group">
            <label class="control-label" for="facility_type">Facility Type</label>
            <div class="controls"><input class="span12" id="facility_type" name="facility_type" type="text" required="" value="<?php echo $data['facility_type']; ?>" /></div>
        </div>                       
      
    </div>
    <!-- // Column END -->



</div>

<input type="hidden" name="fileid" value="<?php echo $file_id; ?>"/>